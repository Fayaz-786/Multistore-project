package com.technoelevate.productcategorymanagementsystem.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.technoelevate.productcategorymanagementsystem.dto.ProductDetailsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ProductsDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Categories;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.entity.OptionTypes;
import com.technoelevate.productcategorymanagementsystem.entity.Products;
import com.technoelevate.productcategorymanagementsystem.entity.VariationTypes;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductDetailsNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductsNotSavedException;
import com.technoelevate.productcategorymanagementsystem.repository.CategoriesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;
import com.technoelevate.productcategorymanagementsystem.repository.OptionTypesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.ProductsRepository;
import com.technoelevate.productcategorymanagementsystem.repository.VariationTypesRepository;

@SpringBootTest
class ProductsServiceImplTest {

	@Mock
	private ProductsRepository productsRepository;

	@Mock
	private DepartmentsRepository departmentsRepository;

	@Mock
	private CategoriesRepository categoriesRepository;
	@Mock
	private VariationTypesRepository variationTypesRepository;
	@Mock
	private OptionTypesRepository optionTypesRepository;

	@InjectMocks
	private ProductsServiceImpl service;

	@Test
	void saveProducts() {
		ProductsDTO productsDTO = new ProductsDTO(1, "OnePlus", 1, 1, 1, 1);
		Optional<Products> products = Optional.empty();
		Optional<Departments> departments = Optional.of(new Departments(1, "Gadgets", null, null));
		Optional<Categories> categories = Optional.of(new Categories(1, "Mobiles", null, null, null, null));
		Optional<VariationTypes> variationType = Optional.of(new VariationTypes(1, "Green", null, null, null));
		Optional<OptionTypes> optionType = Optional.of(new OptionTypes(1, "Green 4gb", null, null, null));
		Products products2 = new Products();
		products2.setCategories(categories.get());
		products2.setDepartments(departments.get());
		products2.setOptionTypes(optionType.get());
		products2.setVariationTypes(variationType.get());
		products2.setProductTitle("OnePlus");

		when(productsRepository.findByProductId(anyInt())).thenReturn(products);
		when(categoriesRepository.findByCategoryId(anyInt())).thenReturn(categories);
		when(departmentsRepository.findByDepartmentId(anyInt())).thenReturn(departments);
		when(variationTypesRepository.findByVariationTypeId(anyInt())).thenReturn(variationType);
		when(optionTypesRepository.findByOptionTypeId(anyInt())).thenReturn(optionType);
		when(productsRepository.save(any())).thenReturn(products2);

		ProductsDTO saveProducts = service.saveProducts(productsDTO);
		assertEquals("OnePlus", saveProducts.getProductTitle());
	}

	@Test
	void saveProductsFail() {
		ProductsDTO productsDTO = new ProductsDTO(1, "OnePlus", 1, 1, 1, 1);
		Optional<Products> products = Optional.of(new Products(1, "OnePlus", null, null, null, null, null));
		Optional<Departments> departments = Optional.of(new Departments(1, "Gadgets", null, null));
		Optional<Categories> categories = Optional.of(new Categories(1, "Mobiles", null, null, null, null));
		Optional<VariationTypes> variationType = Optional.of(new VariationTypes(1, "Green", null, null, null));
		Optional<OptionTypes> optionType = Optional.of(new OptionTypes(1, "Green 4gb", null, null, null));

		when(productsRepository.findByProductId(anyInt())).thenReturn(products);
		when(categoriesRepository.findByCategoryId(anyInt())).thenReturn(categories);
		when(departmentsRepository.findByDepartmentId(anyInt())).thenReturn(departments);
		when(variationTypesRepository.findByVariationTypeId(anyInt())).thenReturn(variationType);
		when(optionTypesRepository.findByOptionTypeId(anyInt())).thenReturn(optionType);

		assertThatThrownBy(() -> service.saveProducts(productsDTO)).isInstanceOf(ProductsNotSavedException.class);
	}

	@Test
	void getProducts() {
		Optional<Departments> departments = Optional.of(new Departments(1, "Gadgets", null, null));
		Optional<Categories> categories = Optional.of(new Categories(1, "Mobiles", null, null, null, null));
		Optional<OptionTypes> optionType = Optional.of(new OptionTypes(1, "Green 4gb", null, null, null));
		Optional<VariationTypes> variationType = Optional.of(new VariationTypes(1, "Green", null, null, null));
		Optional<Products> products = Optional.of(new Products(1, "OnePlus", departments.get(), categories.get(),
				variationType.get(), optionType.get(), null));

		ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();
		productDetailsDTO.setDepartmentTitle(products.get().getDepartments().getDepartmentTitle());
		productDetailsDTO.setCategoryTitle(products.get().getCategories().getCategoryTitle());
		productDetailsDTO.setOptionTypeTitle(products.get().getOptionTypes().getOptionTypeTitle());
		productDetailsDTO.setVariationTypeTitle(products.get().getVariationTypes().getVariationTypeTitle());
		productDetailsDTO.setProductTitle(products.get().getProductTitle());

		when(productsRepository.findByProductId(anyInt())).thenReturn(products);
		ProductDetailsDTO products2 = service.getProducts(1);
		assertEquals("OnePlus", products2.getProductTitle());
	}

	@Test
	void getProductsFail() {
		when(productsRepository.findByProductId(anyInt())).thenReturn(Optional.empty());
		assertThatThrownBy(() -> service.getProducts(1)).isInstanceOf(ProductDetailsNotFoundException.class);

	}

	@Test
	void updateProducts() {
		Optional<Products> products = Optional.of(new Products(1, "OnePlus", null, null, null, null, null));
		ProductsDTO productsDTO = new ProductsDTO(1, "OnePlus", 1, 1, 1, 1);
		when(productsRepository.findByProductId(anyInt())).thenReturn(products);
		when(productsRepository.save(any())).thenReturn(products.get());
		ProductsDTO updateProductsDTO = service.update(productsDTO);
		assertEquals("OnePlus", updateProductsDTO.getProductTitle());
	}

	@Test
	void updateProductsFail() {
		ProductsDTO productsDTO = new ProductsDTO(1, "OnePlus", 1, 1, 1, 1);
		Optional<Products> optional = Optional.empty();
		when(productsRepository.findByProductId(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.update(productsDTO)).isInstanceOf(IdNotFoundException.class);
	}

	@Test
	void deleteProducts() {
		Optional<Products> products = Optional.of(new Products(1, "OnePlus", null, null, null, null, null));
		when(productsRepository.findByProductId(anyInt())).thenReturn(products);
		ProductsDTO deleteProducts = service.deleteProducts(products.get().getProductId());
		assertEquals(null, deleteProducts.getProductTitle());
		verify(productsRepository, times(1)).deleteById(products.get().getProductId());

	}

	@Test
	void deleteProductsFail() {
		Optional<Products> optional = Optional.empty();
		when(productsRepository.findByProductId(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.deleteProducts(1)).isInstanceOf(IdNotFoundException.class);
	}

}
