package com.technoelevate.productcategorymanagementsystem.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.technoelevate.productcategorymanagementsystem.dto.CategoriesDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Categories;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.exception.CategoriesNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.CategoriesNotSavedException;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.CategoriesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;

@SpringBootTest
class CategoriesServiceImplTest {

	@Mock
	private CategoriesRepository repository;

	@Mock
	private DepartmentsRepository departmentsRepository;

	@InjectMocks
	private CategoriesServiceImpl service;

	Departments departments = new Departments(1, "Elecronics", null, null);

	Categories categories = new Categories(1, "mobile", departments, null, null, null);
	List<Categories> list = List.of(categories);

	CategoriesDTO categoriesDTO = new CategoriesDTO(1, "Mobiles", 1);

	@Test
	void saveCategories() {
		Optional<Categories> categories = Optional.empty();
		Optional<Departments> departments = Optional.of(new Departments(1, "Gadgets", null, null));

		Categories categories2 = new Categories();
		categories2.setCategoryId(1);
		categories2.setCategoryTitle("Mobiles");
		categories2.setOptionTypes(null);
		categories2.setProducts(null);
		categories2.setVariationTypes(null);
		categories2.setDepartments(departments.get());

		when(repository.findByCategoryId(anyInt())).thenReturn(categories);
		when(departmentsRepository.findByDepartmentId(anyInt())).thenReturn(departments);
		when(repository.save(categories2)).thenReturn(categories2);
		assertEquals(categoriesDTO, service.saveCategories(categoriesDTO));
	}

	@Test
	void saveCategoriesFail() {
		Optional<Categories> optional = Optional.of(new Categories(1, "Lights", null, null, null, null));
		Optional<Departments> departments = Optional.of(new Departments(1, "Electronics", null, null));
		when(repository.findByCategoryId(anyInt())).thenReturn(optional);
		when(departmentsRepository.findByDepartmentId(anyInt())).thenReturn(departments);
		assertThatThrownBy(() -> service.saveCategories(categoriesDTO)).isInstanceOf(CategoriesNotSavedException.class);
	}

	@Test
	void getCategories() {
		categoriesDTO.setDepartmentId(list.get(0).getDepartments().getDepartmentId());
		when(repository.findAll()).thenReturn(list);
		assertEquals(1, service.getCategories().size());
	}

	@Test
	void getCategoriesFail() {
		List<Categories> list = new ArrayList<>();
		when(repository.findAll()).thenReturn(list);
		assertThatThrownBy(() -> service.getCategories()).isInstanceOf(CategoriesNotFoundException.class);
	}

	@Test
	void updateCategories() {
		Optional<Categories> optional = Optional.of(new Categories(1, "Lights", null, null, null, null));
		when(repository.findByCategoryId(anyInt())).thenReturn(optional);
		when(repository.save(any())).thenReturn(categories);
		CategoriesDTO updateCategories = service.updateCategories(categoriesDTO);
		assertEquals("Mobiles", updateCategories.getCategoryTitle());
	}

	@Test
	void updateCategoriesFail() {
		Optional<Categories> optional = Optional.empty();
		when(repository.findById(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.updateCategories(categoriesDTO)).isInstanceOf(IdNotFoundException.class);
	}

	@Test
	void deleteCategories() {
		Optional<Categories> optional = Optional.of(new Categories(1, "Lights", null, null, null, null));
		when(repository.findByCategoryId(anyInt())).thenReturn(optional);
		service.deleteCategories(optional.get().getCategoryId());
		verify(repository, times(1)).deleteById(optional.get().getCategoryId());
	}

	@Test
	void deleteCategoriesFail() {
		Optional<Categories> optional = Optional.empty();
		when(repository.findById(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.deleteCategories(1)).isInstanceOf(IdNotFoundException.class);
	}

}
