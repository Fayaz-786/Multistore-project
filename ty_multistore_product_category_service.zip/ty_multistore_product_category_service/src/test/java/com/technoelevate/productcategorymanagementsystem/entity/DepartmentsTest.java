package com.technoelevate.productcategorymanagementsystem.entity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class DepartmentsTest {

	ObjectMapper mapper = new ObjectMapper();
	String json = "{\"departmentId\":1,\"departmentTitle\":\"Gadgets\",\"products\":null,\"categories\":null}";

	@Test
	void serializeTestForDepartments() throws JsonMappingException, JsonProcessingException {
		Departments departments = new Departments();
		departments.setDepartmentId(1);
		departments.setDepartmentTitle("Gadgets"); 
		departments.setCategories(null);
		departments.setProducts(null);
		mapper.readValue(json, Departments.class);
		String writeValueAsString = mapper.writeValueAsString(departments);
		assertThat(writeValueAsString).isEqualTo(json);
	}

	@Test
	void deserializeTestForDepartments() throws JsonMappingException, JsonProcessingException {
		Departments departments = mapper.readValue(json, Departments.class);
		assertEquals(1, departments.getDepartmentId());
	}
}
