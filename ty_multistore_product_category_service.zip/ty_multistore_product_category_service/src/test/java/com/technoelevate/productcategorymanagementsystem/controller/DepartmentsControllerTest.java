package com.technoelevate.productcategorymanagementsystem.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoelevate.productcategorymanagementsystem.dto.DepartmentsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.DepartmentsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class DepartmentsControllerTest {

	private MockMvc mockMvc;

	@Mock
	private DepartmentsService service;
	@InjectMocks
	private DepartmentsController controller;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	void saveDepartments() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		DepartmentsDTO dto = new DepartmentsDTO(1, "Electronics");
		String contentAsString = mockMvc
				.perform(post("/api/v1/saveDepartments").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.saveDepartments(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("departments details saved successfully", responseDto.getMessage());
	}

	@Test
	void getDepartments() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		List<DepartmentsDTO> list = new ArrayList<>();
		DepartmentsDTO departmentsDTO = new DepartmentsDTO(1, "Electronics");
		list.add(departmentsDTO);
		String contentAsString = mockMvc
				.perform(get("/api/v1/getDepartments").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(departmentsDTO)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.getDepartments()).thenReturn(list);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("Details of departments", responseDto.getMessage());
	}

	@Test
	void deleteDepartments() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		DepartmentsDTO departmentsDTO = new DepartmentsDTO();
		String contentAsString = mockMvc
				.perform(MockMvcRequestBuilders.delete("/api/v1//deleteDepartments/1")
						.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
						.content(mapper.writeValueAsString(departmentsDTO)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.deleteDepartments(anyInt())).thenReturn(departmentsDTO);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("departments deleted successfully", responseDto.getMessage());
	}

	@Test
	void updateDepartments() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		DepartmentsDTO dto = new DepartmentsDTO(1, "Electronics");
		String contentAsString = mockMvc
				.perform(put("/api/v1/updateDepartments").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.updateDepartments(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("departments updated successfully", responseDto.getMessage());
	}

}
