package com.technoelevate.productcategorymanagementsystem.entity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class CategoriesTest {

	ObjectMapper mapper = new ObjectMapper();
	String json = "{\"categoryId\":1,\"categoryTitle\":\"Mobiles\",\"products\":null,\"variationTypes\":null,\"optionTypes\":null}";
 
	@Test
	void serializeTestForCategories() throws JsonProcessingException {
		Categories categories = new Categories(); 
		categories.setCategoryId(1);
		categories.setCategoryTitle("Mobiles");
		categories.setDepartments(null);
		categories.setProducts(null);
		categories.setVariationTypes(null);
		categories.setOptionTypes(null);
		String writeValueAsString = mapper.writeValueAsString(categories);
		mapper.readValue(json, Categories.class);
		assertThat(writeValueAsString).isEqualTo(json);
	}
	@Test
	void deserializeTestForCategories() throws JsonMappingException, JsonProcessingException {
		Categories categories = mapper.readValue(json, Categories.class);
		assertEquals(1, categories.getCategoryId());
	}

}
