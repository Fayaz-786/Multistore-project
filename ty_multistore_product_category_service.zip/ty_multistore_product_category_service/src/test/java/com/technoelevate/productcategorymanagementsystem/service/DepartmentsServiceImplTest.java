package com.technoelevate.productcategorymanagementsystem.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.technoelevate.productcategorymanagementsystem.dto.DepartmentsDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentsNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentsNotSavedException;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;

@SpringBootTest
class DepartmentsServiceImplTest {
	@Mock
	private DepartmentsRepository repository;

	@InjectMocks
	private DepartmentsServiceImpl service;

	DepartmentsDTO departmentsDTO = new DepartmentsDTO(1, "Gadgets");
	Departments departments = new Departments(1, "Gadgets", null, null);

	@Test
	void saveDepartmentsSuccess() {
		Optional<Departments> department = Optional.empty();
		Departments departments1 = new Departments();
		departments1.setDepartmentId(1);
		departments1.setDepartmentTitle("Gadgets");
		departments1.setCategories(null);
		departments1.setProducts(null);

		when(repository.findByDepartmentId(anyInt())).thenReturn(department);
		when(repository.save(departments1)).thenReturn(departments1);
		assertEquals(departmentsDTO, service.saveDepartments(departmentsDTO));
	}

	@Test
	void saveDepartmentsFail() {
		Optional<Departments> optional = Optional.of(new Departments(1, "gadgets", null, null));
		when(repository.findByDepartmentId(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.saveDepartments(departmentsDTO))
				.isInstanceOf(DepartmentsNotSavedException.class);
	}

	@Test
	void getDepartments() {

		List<Departments> list = new ArrayList<>();
		list.add(departments);
		List<DepartmentsDTO> listDto = new ArrayList<>();
		listDto.add(departmentsDTO);
		when(repository.findAll()).thenReturn(list);
		assertEquals(1, service.getDepartments().size());
	}

	@Test
	void getDepartmentsFail() {
		List<Departments> list = new ArrayList<>();
		when(repository.findAll()).thenReturn(list);
		assertThatThrownBy(() -> service.getDepartments()).isInstanceOf(DepartmentsNotFoundException.class);

	}

	@Test
	void updateDepartments() {
		Optional<Departments> optional = Optional.of(new Departments(1, "Electronics", null, null));
		when(repository.findById(anyInt())).thenReturn(optional);
		when(repository.save(any())).thenReturn(departments);
		DepartmentsDTO updateDepartments = service.updateDepartments(departmentsDTO);
		assertEquals("Gadgets", updateDepartments.getDepartmentTitle());
	}

	@Test
	void updateDepartmentsFail() {
		Optional<Departments> optional = Optional.empty();
		when(repository.findById(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.updateDepartments(departmentsDTO)).isInstanceOf(IdNotFoundException.class);
	}

	@Test
	void deleteDepartments() {
		Optional<Departments> optional = Optional.of(new Departments(1, "gadgets", null, null));
		when(repository.findById(anyInt())).thenReturn(optional);
		DepartmentsDTO deleteDepartments = service.deleteDepartments(optional.get().getDepartmentId());
		assertEquals(null, deleteDepartments.getDepartmentTitle());
		verify(repository, times(1)).deleteById(optional.get().getDepartmentId());
	}

	@Test
	void deleteDepartmentsFail() {
		Optional<Departments> optional = Optional.empty();
		when(repository.findById(anyInt())).thenReturn(optional);
		assertThatThrownBy(() -> service.deleteDepartments(1)).isInstanceOf(IdNotFoundException.class);
	}

}
