package com.technoelevate.productcategorymanagementsystem.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoelevate.productcategorymanagementsystem.dto.CategoriesDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.CategoriesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class CategoriesControllerTest {

	private MockMvc mockMvc;

	@Mock
	private CategoriesService service;
	@InjectMocks
	private CategoriesController controller;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	void saveCategories() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		CategoriesDTO dto = new CategoriesDTO(1, "Lights", 1);
		String contentAsString = mockMvc
				.perform(post("/api/v1/saveCategories").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.saveCategories(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("categories details saved successfully", responseDto.getMessage());
	}

	@Test
	void getCategories() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		List<CategoriesDTO> list = new ArrayList<>();
		CategoriesDTO dto = new CategoriesDTO(1, "Lights", 1);
		list.add(dto);
		String contentAsString = mockMvc
				.perform(get("/api/v1/getCategories").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.getCategories()).thenReturn(list);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("Details of categories", responseDto.getMessage());
	}

	@Test
	void deleteCategories() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		CategoriesDTO dto = new CategoriesDTO(1, "Lights", 1);
		String contentAsString = mockMvc
				.perform(MockMvcRequestBuilders.delete("/api/v1//deleteCategories/1").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.deleteCategories(anyInt())).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("categories deleted successfully", responseDto.getMessage());
	}
 
	@Test
	void updateCategories() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		CategoriesDTO dto = new CategoriesDTO(1, "Lights", 1);
		String contentAsString = mockMvc
				.perform(put("/api/v1/updateCategories").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.updateCategories(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("Categories updated successfully", responseDto.getMessage());
	}
}
