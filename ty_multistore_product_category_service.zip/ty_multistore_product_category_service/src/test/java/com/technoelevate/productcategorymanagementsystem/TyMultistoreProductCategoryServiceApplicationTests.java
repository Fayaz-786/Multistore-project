package com.technoelevate.productcategorymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TyMultistoreProductCategoryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
