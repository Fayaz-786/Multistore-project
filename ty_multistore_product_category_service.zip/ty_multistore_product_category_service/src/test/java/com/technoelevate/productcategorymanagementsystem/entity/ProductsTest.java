package com.technoelevate.productcategorymanagementsystem.entity;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
class ProductsTest {

	ObjectMapper objectMapper = new ObjectMapper();
	String json = "{\"productId\":1,\"productTitle\":\"OnePlus\",\"productVariations\":null}";

	@Test
	void serializeTestForProduct() throws JsonProcessingException {
		Products products = new Products();
		products.setProductId(1);
		products.setProductTitle("OnePlus"); 
		products.setDepartments(null);
		products.setCategories(null);
		products.setOptionTypes(null);
		products.setProductVariations(null);
		products.setVariationTypes(null);
		objectMapper.readValue(json, Products.class);
		String writeValueAsString = objectMapper.writeValueAsString(products);
		assertThat(writeValueAsString).isEqualTo(json);
	}

	@Test
	void deserializeTestForProduct() throws JsonMappingException, JsonProcessingException {
		Products readValue = objectMapper.readValue(json, Products.class);
		assertEquals(1, readValue.getProductId());
	}
}
