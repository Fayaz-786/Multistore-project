package com.technoelevate.productcategorymanagementsystem.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.technoelevate.productcategorymanagementsystem.dto.ProductDetailsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ProductsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.ProductsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class ProductsControllerTest {

	private MockMvc mockMvc;

	@Mock
	private ProductsService service;

	@InjectMocks
	private ProductsController controller;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(controller).build();
	}

	@Test
	void saveProducts() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ProductsDTO dto = new ProductsDTO(1, "samsung", 1, 1, 1, 1);
		String contentAsString = mockMvc
				.perform(post("/api/v1/products/create").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.saveProducts(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("Product details saved successfully", responseDto.getMessage());
	}

	@Test
	void getProducts() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO("samsung", "Electronics", "mobile", "colour",
				"red");
		String contentAsString = mockMvc
				.perform(get("/api/v1/products/details/3").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(productDetailsDTO)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.getProducts(anyInt())).thenReturn(productDetailsDTO);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("details of products", responseDto.getMessage());
	}

	@Test
	void delete() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ProductsDTO productsDTO = new ProductsDTO();
		String contentAsString = mockMvc
				.perform(MockMvcRequestBuilders.delete("/api/v1/products/delete/1").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(productsDTO)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.deleteProducts(anyInt())).thenReturn(productsDTO);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("product deleted successfully", responseDto.getMessage());
	}

	@Test
	void update() throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ProductsDTO dto = new ProductsDTO(1, "samsung", 1, 1, 1, 1);
		String contentAsString = mockMvc
				.perform(put("/api/v1/products/update").accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON).content(mapper.writeValueAsString(dto)))
				.andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
		log.info("contentAsString{}", contentAsString);
		when(service.saveProducts(dto)).thenReturn(dto);
		ResponseDTO responseDto = mapper.readValue(contentAsString, ResponseDTO.class);
		assertEquals("product updated successfully", responseDto.getMessage());
	}

}
