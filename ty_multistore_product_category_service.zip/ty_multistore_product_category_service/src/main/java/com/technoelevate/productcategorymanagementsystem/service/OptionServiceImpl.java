package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.OptionConstant;
import com.technoelevate.productcategorymanagementsystem.dto.OptionDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Options;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.OptionNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.OptionRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OptionServiceImpl implements OptionService {
	@Autowired
	private OptionRepository optionRepository;

	@Override
	public OptionDTO register(OptionDTO optionDTO) {
		log.info(OptionConstant.ENTERED_INTO_REGISTER_OPTION_SERVICE);
		Optional<Options> findByOptionId = optionRepository.findByOptionId(optionDTO.getOptionId());
		if (findByOptionId.isEmpty()) {

			Options options = new Options();
			BeanUtils.copyProperties(optionDTO, options);
			Options save = optionRepository.save(options);
			BeanUtils.copyProperties(save, optionDTO);
			return optionDTO;
		}
		log.info(OptionConstant.EXCEPTION_OCCURED_IN_REGISTER_OPTION_SERVICE);
		throw new OptionNotFoundException(OptionConstant.SOMETHING_WENT_WRONG);

	}

	@Override
	public List<OptionDTO> getOption() {
		log.info(OptionConstant.ENTERED_INTO_GET_OPTION_SERVICE);
		List<OptionDTO> optionList = new ArrayList<>();
		List<Options> findAll = optionRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(i -> {
				OptionDTO optionDTO = new OptionDTO();
				BeanUtils.copyProperties(i, optionDTO);
				optionList.add(optionDTO);
			});

			return optionList;
		}
		log.info(OptionConstant.EXCEPTION_OCCURED_IN_GET_OPTION_SERVICE);
		throw new OptionNotFoundException("option not available, Please try again");
	}

	@Override
	public OptionDTO updateOption(OptionDTO optionDTO) {
		log.info(OptionConstant.ENTERED_INTO_REGISTER_OPTION_SERVICE);
		Optional<Options> optionId = optionRepository.findById(optionDTO.getOptionId());
		if (optionId.isPresent()) {
			OptionDTO optionDto2 = new OptionDTO();
			optionDto2.setOptionTitle(optionDTO.getOptionTitle());
			optionId.get().setOptionTitle(optionDTO.getOptionTitle());
			BeanUtils.copyProperties(optionDTO, optionId.get());
			Options save = optionRepository.save(optionId.get());
			BeanUtils.copyProperties(save, optionDTO);
			return optionDTO;
		}
		log.info(OptionConstant.EXCEPTION_OCCURED_IN_UPDATE_OPTION_SERVICE);
		throw new IdNotFoundException(OptionConstant.ID_NOT_PRESENT);
	}

	@Override
	public OptionDTO deleteOption(Integer optionId) {
		log.info(OptionConstant.ENTERED_INTO_DELETE_METHOD_SERVICE);
		Optional<Options> optionsId = optionRepository.findById(optionId);
		if (optionsId.isPresent()) {
			optionRepository.deleteById(optionId);
			return new OptionDTO();
		}
		log.info(OptionConstant.EXCEPTION_OCCURED_IN_DELETE_OPTION_SERVICE);
		throw new IdNotFoundException(OptionConstant.ID_NOT_PRESENT);
	}

}
