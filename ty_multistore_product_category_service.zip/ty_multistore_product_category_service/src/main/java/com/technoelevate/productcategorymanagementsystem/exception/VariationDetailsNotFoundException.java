package com.technoelevate.productcategorymanagementsystem.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@SuppressWarnings("serial")
@Getter
@AllArgsConstructor

public class VariationDetailsNotFoundException extends RuntimeException{
	
	private final String message;

}
