package com.technoelevate.productcategorymanagementsystem.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.OptionTypesConstant;
import com.technoelevate.productcategorymanagementsystem.dto.OptionTypesDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.OptionTypesService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class OptionTypesController {

	@Autowired
	private OptionTypesService optionTypesService;

	@PostMapping("/saveOptionTypes")
	public ResponseEntity<ResponseDTO> saveOptionTypes(@Valid @RequestBody OptionTypesDTO optionTypesDTO) {
		log.info(OptionTypesConstant.ENTERED_INTO_SAVE_OPTIONTYPES_METHOD_OF_CONTROLLER);

		return ResponseEntity.ok(new ResponseDTO(false, OptionTypesConstant.OPTIONTYPES_DETAILS_SAVED_SUCCESSFULLY,
				optionTypesService.saveOptionTypes(optionTypesDTO)));
	}
 
	@GetMapping("/getOptionTypes")
	public ResponseEntity<ResponseDTO> getOptionTypes() {
		log.info(OptionTypesConstant.ENTERED_INTO_GET_OPTIONTYPES_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, OptionTypesConstant.DETAILS_OF_OPTIONTYPES,
				optionTypesService.getOptionTypes()));
	}

	@PutMapping("/updateOptionTypes")
	public ResponseEntity<ResponseDTO> updateOptionTypes(@Valid @RequestBody OptionTypesDTO optionTypesDTO) {
		log.info(OptionTypesConstant.ENTERED_INTO_UPDATE_OPTIONTYPES_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, OptionTypesConstant.OPTIONTYPES_UPDATED_SUCCESSFULLY,
				optionTypesService.updateOptionTypes(optionTypesDTO)));
	}

	@DeleteMapping("/deleteOptionTypes/{optionTypeId}")
	public ResponseEntity<ResponseDTO> deleteOptionTypes(@PathVariable Integer optionTypeId) {
		log.info(OptionTypesConstant.ENTERED_INTO_DELETE_OPTIONTYPES_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, OptionTypesConstant.OPTIONTYPES_DELETED_SUCCESSFULLY,
				optionTypesService.deleteOptionTypes(optionTypeId)));
	}
}
