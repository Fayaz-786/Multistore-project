package com.technoelevate.productcategorymanagementsystem.constant;

public class ProductVariationConstant {
	/* ----------------------GET------------------------------------------ */
	public static final String GET_PRODUCTION_TYPE = "get all variation types";
	public static final String EXCEPTION_OCCURED_IN_GET_PRODUCT_VARIATION = "Something went wrong";
	/* ----------------------REGISTER------------------------------------------ */

	public static final String SUCCESS = "Registration Successful";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong";
	public static final String ENTERED_INTO_REGISTER = "Register the option";
	public static final String EXCEPTION_OCCURED_IN_REGISTER_PRODUCT_VARIATION_SERVICE = "Entered inside register";

	/* update ------------------------------------ */
	public static final String UPDATE_SUCCESSFULLY = "Updated Sucessfully";
	public static final String EXCEPTION_OCCURED_IN_UPDATE = "Something went wrong";
	public static final String ID_NOT_PRESENT = "Something went wrong";
	/* delete ------------------------------------ */
	public static final String DELETE_SUCCESSFULLY = "Delete Sucessfully";
	public static final String ENTERED_INTO_DELETE_METHOD_SERVICE = "Delete Sucessfully";
	public static final String EXCEPTION_OCCURED_IN_DELETE_PRODUCT_VARIATION = "Something went wrong";
	/*----------------------------------------- CONTROLLER--------------------------------- */
	public static final String ENTERED_INTO_REGISTER_PRODUCTION_VARIATION_OF__CONTROLLER = "Entered into Register ProductVariation method of controller";
	public static final String ENTERED_INTO_GET_PRODUCTION_VARIATION_OF__CONTROLLER = "Entered into get ProductVariation method of controller";
	public static final String ENTERED_INTO_UPDATE_PRODUCTION_VARIATION_OF__CONTROLLER = "Entered into update ProductVariation method of controller";
	public static final String ENTERED_INTO_DELETE_PRODUCTION_VARIATION_OF__CONTROLLER = "Entered into delete ProductVariation method of controller";
	/*----------------------------------------- service--------------------------------- */
	public static final String ENTERED_INTO_REGISTER_PRODUCT_VARIATION_SERVICE = "Entered into Register productVariation method of service";
	public static final String ENTERED_OCCURED_IN_GET_PRODUCT_VARIATION_SERVICE = "Entered into get productVariation method of service";
	public static final String ENTERED_OCCURED_IN_UPDATE_PRODUCT_VARIATION_SERVICE = "Entered into update productVariation method of service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_PRODUCT_VARIATION_SERVICE = "Exception into update productVariation method of service";
	public static final String EXCEPTION_OCCURED_IN_GET_PRODUCT_VARIATION_SERVICE = "Exception into get productVariation method of service";
	public static final String ENTERED_INTO_DELETE_PRODUCT_VARIATION_SERVICE = "Entered into delete productVariation method of service";
	public static final String EXCEPTION_OCCURED_IN_DELETE_PRODUCT_VARIATION_SERVICE = "Exception into delete productVariation method of service";

}
