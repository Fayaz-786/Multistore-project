package com.technoelevate.productcategorymanagementsystem.constant;

public class OptionTypesConstant {

	/** OptionTypes entity controller constants messages */

	public static final String OPTIONTYPES_DETAILS_SAVED_SUCCESSFULLY = "optiontypes details saved successfully";
	public static final String DETAILS_OF_OPTIONTYPES = "Details of optiontypes";
	public static final String OPTIONTYPES_UPDATED_SUCCESSFULLY = "optiontypes updated successfully";
	public static final String OPTIONTYPES_DELETED_SUCCESSFULLY = "optiontypes deleted successfully";

	public static final String ENTERED_INTO_SAVE_OPTIONTYPES_METHOD_OF_CONTROLLER = "Entered into save optiontypes method of controller";
	public static final String ENTERED_INTO_GET_OPTIONTYPES_METHOD_OF_CONTROLLER = "Entered into get optiontypes method of controller";
	public static final String ENTERED_INTO_UPDATE_OPTIONTYPES_OF_CONTROLLER = "Entered into update optiontypes of controller";
	public static final String ENTERED_INTO_DELETE_OPTIONTYPES_METHOD_OF_CONTROLLER = "Entered into delete optiontypes method of controller";

	/** OptionTypes entity Service messages */
	public static final String ENTERED_INTO_SAVE_OPTIONTYPES_SERVICE = "Entered into save optiontypes service";
	public static final String ENTERED_INTO_GET_OPTIONTYPES_SERVICE = "Entered into get optiontypes service";
	public static final String ENTERED_INTO_UPDATE_OPTIONTYPES_METHOD_IN_SERVICE = "entered into update optiontypes method in service";
	public static final String ENTERED_INTO_DELETE_OPTIONTYPES_METHOD_IN_SERVICE = "Entered into delete optiontypes method in service";

	/** Exception constant messages */
	public static final String SOMETHING_WENT_WRONG = "something went wrong";
	public static final String OPTIONTYPES_NOT_FOUND = "OptionTypes not found";
	public static final String ID_NOT_PRESENT = "Id not present";

	/** log exception message */
	public static final String EXCEPTION_OCCURED_IN_SAVE_OPTIONTYPES_SERVICE = "exception occured in save optiontypes service";
	public static final String EXCEPTION_OCCURED_IN_GET_OPTIONTYPES_SERVICE = "exception occured in get optiontypes service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_OPTIONTYPES_SERVICE = "exception occured in update optiontypes service";
	public static final String EXCEPTION_OCCURED_IN_DELETE_OPTIONTYPES_SERVICE = "Excepiton occured in delete optiontypes service";

}
