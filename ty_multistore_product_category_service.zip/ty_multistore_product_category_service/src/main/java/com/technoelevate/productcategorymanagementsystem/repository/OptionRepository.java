package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.Options;

public interface OptionRepository extends JpaRepository<Options, Integer> {
	
   Optional<Options> findByOptionId(Integer optionId);

}
