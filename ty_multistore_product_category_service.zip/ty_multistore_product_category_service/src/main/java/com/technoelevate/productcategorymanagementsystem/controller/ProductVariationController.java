package com.technoelevate.productcategorymanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.ProductVariationConstant;
import com.technoelevate.productcategorymanagementsystem.dto.ProductVariationDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.ProductVariationService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class ProductVariationController {
	@Autowired
	private ProductVariationService productVariationService;

	@PostMapping("/registerProductVariation")
	public ResponseEntity<ResponseDTO> register(@RequestBody ProductVariationDTO productVariationDTO) {
		log.info(ProductVariationConstant.ENTERED_INTO_REGISTER_PRODUCTION_VARIATION_OF__CONTROLLER);

		return ResponseEntity.ok(new ResponseDTO(false, ProductVariationConstant.SUCCESS, productVariationService.register(productVariationDTO)));
	}

	@GetMapping("/getProductVariation")
	public ResponseEntity<ResponseDTO> getProductVariatio() {
		log.info(ProductVariationConstant.ENTERED_INTO_GET_PRODUCTION_VARIATION_OF__CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, ProductVariationConstant.GET_PRODUCTION_TYPE, productVariationService.getProductVariation()));

	}

	@PutMapping("/updateProductVariation")
	public ResponseEntity<ResponseDTO> updateOption(@RequestBody ProductVariationDTO productVariationDTO) {
		log.info(ProductVariationConstant.ENTERED_INTO_UPDATE_PRODUCTION_VARIATION_OF__CONTROLLER);
		return ResponseEntity
				.ok(new ResponseDTO(false, ProductVariationConstant.UPDATE_SUCCESSFULLY, productVariationService.updateProductVariation(productVariationDTO)));

	}

	@DeleteMapping("/deleteProductVariation/{id}")
	public ResponseEntity<ResponseDTO> deleteOption(@PathVariable Integer id) {
		log.info(ProductVariationConstant.ENTERED_INTO_DELETE_PRODUCTION_VARIATION_OF__CONTROLLER);
		return ResponseEntity
				.ok(new ResponseDTO(false, ProductVariationConstant.DELETE_SUCCESSFULLY, productVariationService.deleteProductVariation(id)));

	}

}
