package com.technoelevate.productcategorymanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.ProductsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.ProductsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.ProductsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/products")
public class ProductsController {

	@Autowired
	private ProductsService productsService;

	@PostMapping("/create")
	public ResponseEntity<ResponseDTO> saveProducts(@RequestBody ProductsDTO productsDto) {
		log.info(ProductsConstant.ENTERED_INTO_SAVE_PRODUCTS_CONTROLLER);

		return ResponseEntity.ok(new ResponseDTO(false, ProductsConstant.PRODUCTS_DETAILS_SAVED_SUCCESSFULLY,
				productsService.saveProducts(productsDto)));
	}

	@GetMapping("/details/{productId}")
	public ResponseEntity<ResponseDTO> getProducts(@PathVariable Integer productId) {
		log.info(ProductsConstant.ENTERED_INTO_GET_PRODUCTS_CONTROLLER);
		return ResponseEntity.ok(
				new ResponseDTO(false, ProductsConstant.GET_PRODUCT_DETAILS, productsService.getProducts(productId)));
	}

	@DeleteMapping("/delete/{productId}")
	public ResponseEntity<ResponseDTO> delete(@PathVariable Integer productId) {
		log.info(ProductsConstant.ENTERED_INTO_DELETE_PRODUCTS_CONTROLLER);
		return ResponseEntity
				.ok(new ResponseDTO(false, ProductsConstant.DELETED, productsService.deleteProducts(productId)));

	}

	@PutMapping("/update")
	public ResponseEntity<ResponseDTO> update(@RequestBody ProductsDTO productsdto) {
		log.info(ProductsConstant.ENTERED_INTO_DELETE_PRODUCTS_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, ProductsConstant.UPDATED, productsService.update(productsdto)));

	}

}
