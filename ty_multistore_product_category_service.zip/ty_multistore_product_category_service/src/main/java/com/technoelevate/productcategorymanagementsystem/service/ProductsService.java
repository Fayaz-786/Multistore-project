package com.technoelevate.productcategorymanagementsystem.service;

import com.technoelevate.productcategorymanagementsystem.dto.ProductDetailsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ProductsDTO;

public interface ProductsService {

	public ProductsDTO saveProducts(ProductsDTO productsDto);

	public ProductsDTO deleteProducts(Integer productId);

	public ProductDetailsDTO getProducts(Integer productId);

	public ProductsDTO update(ProductsDTO productsdto);

}