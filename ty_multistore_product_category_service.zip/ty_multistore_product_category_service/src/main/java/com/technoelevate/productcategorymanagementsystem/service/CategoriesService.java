package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.CategoriesDTO;

public interface CategoriesService {

	public CategoriesDTO saveCategories(CategoriesDTO categoriesDTO);

	public List<CategoriesDTO> getCategories();

	public CategoriesDTO updateCategories(CategoriesDTO categoriesDTO);

	public CategoriesDTO deleteCategories(Integer categoryId);

}
