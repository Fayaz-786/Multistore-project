package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.Categories;

public interface CategoriesRepository extends JpaRepository<Categories, Integer> {

	Optional<Categories> findByCategoryId(Integer categoryId);

}
