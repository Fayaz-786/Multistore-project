package com.technoelevate.productcategorymanagementsystem.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OptionTypesDTO {

	private Integer optionTypeId;

	@NotBlank(message = "option type title not be empty")
	private String optionTypeTitle;

	private Integer categoryId;

}
