package com.technoelevate.productcategorymanagementsystem.constant;

public class VariationsConstant {

	public static final String VARIATIONS_DETAILS_SAVED_SUCCESSFULLY = "variation details saved successfully";

	public static final String SOMETHING_WENT_WRONG = "something went wrong";

	public static final String GET_VARIATIONS_DETAILS = "detalis of variations";

	public static final String DELETED = "variation deleted successfully";

	public static final String UPDATED = "variation updated successfully";

	public static final String EXCEPTION_OCCURED_IN_UPDATE_VARAIATIONS = "exception occured in update variations";

	public static final String VARIATION_ID_NOT_FOUND = "variation id not found";

	public static final String EXCEPTION_OCCURED_IN_DELETE_VARIATIONS = "exception occured in delete variations";

	public static final String ENTERED_INTO_VARIARTIONS = "entered into variations controller";

	public static final String ENTERED_INTO_REGISTER_VARIATIONS = "entered into register variations";

	public static final String ENTERED_INTO_GET_VARIATIONS = "entered into get variations service";

	public static final String ENTERED_INTO_SAVE_VARIARTIONS = "entered into save variations service";

	public static final String ENTERED_INTO_SAVE_VARIARTIONS_CONTROLLER = "entered into save variations controller";

	public static final String ENTERED_INTO_GET_VARIARTIONS_CONTROLLER = "entered into get variations Controller";

	public static final String ENTERED_INTO_DELETE_VARIATION_CONTROLLER = "entered into delete variations Controller";

	public static final String ENTERED_INTO_UPDATE_VARIARTIONS_CONTROLLER = "entered into update variations Controller";;

}
