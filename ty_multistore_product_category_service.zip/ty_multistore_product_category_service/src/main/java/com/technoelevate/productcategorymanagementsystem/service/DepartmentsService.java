package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.DepartmentsDTO;

public interface DepartmentsService {

	public DepartmentsDTO saveDepartments(DepartmentsDTO departmentsDto);

	public List<DepartmentsDTO> getDepartments();

	public DepartmentsDTO updateDepartments(DepartmentsDTO departmentsDto);

	public DepartmentsDTO deleteDepartments(Integer departmentId);

}
