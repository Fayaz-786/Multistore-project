package com.technoelevate.productcategorymanagementsystem.service;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.ProductsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.ProductDetailsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ProductsDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Categories;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.entity.OptionTypes;
import com.technoelevate.productcategorymanagementsystem.entity.Products;
import com.technoelevate.productcategorymanagementsystem.entity.VariationTypes;
import com.technoelevate.productcategorymanagementsystem.exception.CategoryIdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentIdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.OptionTypeIdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductDetailsNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductsNotSavedException;
import com.technoelevate.productcategorymanagementsystem.exception.VariationTypeIdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.CategoriesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;
import com.technoelevate.productcategorymanagementsystem.repository.OptionTypesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.ProductsRepository;
import com.technoelevate.productcategorymanagementsystem.repository.VariationTypesRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProductsServiceImpl implements ProductsService {

	@Autowired
	private ProductsRepository productsRepository;
	@Autowired
	private DepartmentsRepository departmentsRepository;
	@Autowired
	private CategoriesRepository categoriesRepository;
	@Autowired
	private VariationTypesRepository variationTypesRepository;
	@Autowired
	private OptionTypesRepository optionTypesRepository;

	@Override
	public ProductsDTO saveProducts(ProductsDTO productsDto) {

		log.info(ProductsConstant.ENTERED_INTO_SAVE_PRODUCTS);
		Optional<Products> findByProductId = productsRepository.findByProductId(productsDto.getProductId());
		Optional<Departments> findByDepartmentId = Optional
				.ofNullable(departmentsRepository.findByDepartmentId(productsDto.getDepartmentId()).orElseThrow(
						() -> new DepartmentIdNotFoundException(ProductsConstant.PLEASE_ENTER_DEPARTMENT_DETAILS)));
		Optional<Categories> findByCategoryId = Optional
				.ofNullable(categoriesRepository.findByCategoryId(productsDto.getCategoryId()).orElseThrow(
						() -> new CategoryIdNotFoundException(ProductsConstant.PLEASE_ENTER_CATEGORY_DETAILS)));
		Optional<VariationTypes> findByVariationTypeId = Optional
				.ofNullable(variationTypesRepository.findByVariationTypeId(productsDto.getVariationTypeId())
						.orElseThrow(() -> new VariationTypeIdNotFoundException(
								ProductsConstant.PLEASE_ENTER_VALIDATION_TYPE_DETAILS)));
		Optional<OptionTypes> findByOptionTypeId = Optional
				.ofNullable(optionTypesRepository.findByOptionTypeId(productsDto.getOptionTypeId()).orElseThrow(
						() -> new OptionTypeIdNotFoundException(ProductsConstant.PLEASE_ENTER_OPTION_TYPE_DETAILS)));

		if (findByProductId.isEmpty()) {
			Products product = new Products();
			BeanUtils.copyProperties(productsDto, product);
			product.setDepartments(findByDepartmentId.get());
			product.setCategories(findByCategoryId.get());
			product.setVariationTypes(findByVariationTypeId.get());
			product.setOptionTypes(findByOptionTypeId.get());
			Products save = productsRepository.save(product);
			BeanUtils.copyProperties(save, productsDto);
			return productsDto;
		}

		log.info(ProductsConstant.EXCEPTION_OCCURED_IN_SAVE_PRODUCTS);
		throw new ProductsNotSavedException(ProductsConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public ProductDetailsDTO getProducts(Integer productId) {
		ProductDetailsDTO dto = new ProductDetailsDTO();
		Optional<Products> findByProductId = productsRepository.findByProductId(productId);
		if (findByProductId.isPresent()) {
			Products products = findByProductId.get();
			dto.setProductTitle(products.getProductTitle());
			dto.setDepartmentTitle(products.getDepartments().getDepartmentTitle());
			dto.setCategoryTitle(products.getCategories().getCategoryTitle());
			dto.setVariationTypeTitle(products.getVariationTypes().getVariationTypeTitle());
			dto.setOptionTypeTitle(products.getOptionTypes().getOptionTypeTitle());
			return dto;
		}
		log.info(ProductsConstant.EXCEPTION_OCCURED_IN_GET_PRODUCTS);
		throw new ProductDetailsNotFoundException(ProductsConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public ProductsDTO deleteProducts(Integer productId) {
		log.info(ProductsConstant.ENTERED_INTO_DELETE_PRODUCTS);
		Optional<Products> findByProductId = productsRepository.findByProductId(productId);
		if (findByProductId.isPresent()) {
			productsRepository.deleteById(findByProductId.get().getProductId());
			return new ProductsDTO();
		}
		log.info(ProductsConstant.EXCEPTION_OCCURED_IN_DELETE_PRODUCTS);
		throw new IdNotFoundException(ProductsConstant.PRODUCT_ID_NOT_FOUND);

	}

	@Override
	public ProductsDTO update(ProductsDTO productdto) {
		log.info(ProductsConstant.ENTERED_INTO_UPDATE_PRODUCTS);
		Optional<Products> findByProductId = productsRepository.findByProductId(productdto.getProductId());
		if (findByProductId.isPresent()) {
			Products product = findByProductId.get();
			BeanUtils.copyProperties(productdto, product);
			productsRepository.save(product);
			BeanUtils.copyProperties(product, productdto);
			return productdto;
		}
		log.info(ProductsConstant.EXCEPTION_OCCURED_IN_UPDATE_PRODUCTS);
		throw new IdNotFoundException(ProductsConstant.PRODUCT_ID_NOT_FOUND);
	}
}
