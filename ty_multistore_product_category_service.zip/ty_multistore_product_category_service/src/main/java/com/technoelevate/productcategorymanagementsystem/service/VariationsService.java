package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.VariationsDTO;

public interface VariationsService {

	public VariationsDTO saveVariations(VariationsDTO variationDto);

	public List<VariationsDTO> getVariations();
	
	public VariationsDTO deleteVariations(Integer variationId);

	public VariationsDTO update(VariationsDTO variationsdto, Integer variationId);



}
