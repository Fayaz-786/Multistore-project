package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.OptionConstant;
import com.technoelevate.productcategorymanagementsystem.constant.ProductVariationConstant;
import com.technoelevate.productcategorymanagementsystem.dto.ProductVariationDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Options;
import com.technoelevate.productcategorymanagementsystem.entity.ProductVariations;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductVariationNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.ProductVariationNotRegisterException;
import com.technoelevate.productcategorymanagementsystem.repository.ProductVariationRepository;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ProductVariationServiceImpl implements ProductVariationService {
	@Autowired
	private ProductVariationRepository productVariationRepository;

	@Override
	public ProductVariationDTO register(ProductVariationDTO productVariationDTO) {
		 log.info(ProductVariationConstant.ENTERED_INTO_REGISTER_PRODUCT_VARIATION_SERVICE);
		 Optional<Options> productVariationId = productVariationRepository.productVariationId(productVariationDTO.getProductVariationId());
		 if(productVariationId.isEmpty()) {
		 
			ProductVariations productVariations = new ProductVariations();
	        

			
			BeanUtils.copyProperties(productVariationDTO, productVariations);
			 ProductVariations save = productVariationRepository.save(productVariations);
			BeanUtils.copyProperties(save, productVariationDTO);
			return productVariationDTO;
	}
		log.info(ProductVariationConstant.EXCEPTION_OCCURED_IN_REGISTER_PRODUCT_VARIATION_SERVICE);
		throw new ProductVariationNotRegisterException(ProductVariationConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public List<ProductVariationDTO> getProductVariation() {
		log.info(ProductVariationConstant.ENTERED_OCCURED_IN_GET_PRODUCT_VARIATION_SERVICE);
		List<ProductVariationDTO> productVariationList = new ArrayList<>();
		List<ProductVariations> findAll = productVariationRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(i -> {
				ProductVariationDTO productVariationDTO = new ProductVariationDTO();
				BeanUtils.copyProperties(i, productVariationDTO);
				productVariationList.add(productVariationDTO);
			});

			return productVariationList;
		}
        log.info(ProductVariationConstant.EXCEPTION_OCCURED_IN_GET_PRODUCT_VARIATION_SERVICE);
		throw new ProductVariationNotFoundException("ProductVariation not available, Please try again");
	}
	

	@Override
	public ProductVariationDTO updateProductVariation(ProductVariationDTO productVariationDTO) {
		log.info(ProductVariationConstant.ENTERED_OCCURED_IN_UPDATE_PRODUCT_VARIATION_SERVICE);
	 Optional<ProductVariations> productVariationId = productVariationRepository.findById(productVariationDTO.getProductVariationId());
		if(productVariationId.isPresent() ){
			BeanUtils.copyProperties(productVariationDTO, productVariationId.get());
			productVariationRepository.save(productVariationId.get());
			BeanUtils.copyProperties( productVariationId.get(),productVariationDTO);
			return productVariationDTO;
		}
		log.info(ProductVariationConstant.EXCEPTION_OCCURED_IN_UPDATE_PRODUCT_VARIATION_SERVICE);
		throw new IdNotFoundException(OptionConstant.ID_NOT_PRESENT);
	}

	

	@Override
	public ProductVariationDTO deleteProductVariation(Integer productVariationId) {
		log.info(ProductVariationConstant.ENTERED_INTO_DELETE_PRODUCT_VARIATION_SERVICE);
		 Optional<ProductVariations> productVariatioId = productVariationRepository.findById(productVariationId);
		if(productVariatioId.isPresent()){
			productVariationRepository.deleteById(productVariationId);
		return new ProductVariationDTO();
		}
			log.info(ProductVariationConstant.EXCEPTION_OCCURED_IN_DELETE_PRODUCT_VARIATION_SERVICE);
			throw new IdNotFoundException(OptionConstant.ID_NOT_PRESENT);
	}

	




	

}
