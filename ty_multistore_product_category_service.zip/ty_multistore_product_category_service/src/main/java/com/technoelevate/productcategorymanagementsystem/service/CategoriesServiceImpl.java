package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.CategoriesConstant;
import com.technoelevate.productcategorymanagementsystem.constant.ProductsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.CategoriesDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Categories;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.exception.CategoriesNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.CategoriesNotSavedException;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentIdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.CategoriesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CategoriesServiceImpl implements CategoriesService {

	@Autowired
	private CategoriesRepository categoriesRepository;

	@Autowired
	private DepartmentsRepository departmentsRepository;

	@Override
	public CategoriesDTO saveCategories(CategoriesDTO categoriesDTO) { 
		log.info(CategoriesConstant.ENTERED_INTO_SAVE_CATEGORIES_SERVICE);

		Optional<Categories> findByCategoryId = categoriesRepository.findByCategoryId(categoriesDTO.getCategoryId());
		Optional<Departments> findByDepartmentId = Optional
				.ofNullable(departmentsRepository.findByDepartmentId(categoriesDTO.getDepartmentId()).orElseThrow(
						() -> new DepartmentIdNotFoundException(ProductsConstant.PLEASE_ENTER_DEPARTMENT_DETAILS)));
		if (findByCategoryId.isEmpty()) {
			Departments departments = findByDepartmentId.get();
			Categories categories = new Categories();
			BeanUtils.copyProperties(categoriesDTO, categories);
			categories.setDepartments(departments);
			Categories save = categoriesRepository.save(categories);
			BeanUtils.copyProperties(save, categoriesDTO);
			return categoriesDTO;
		}
		log.info(CategoriesConstant.EXCEPTION_OCCURED_IN_SAVE_CATEGORIES_SERVICE);
		throw new CategoriesNotSavedException(CategoriesConstant.CATEGORIES_DETAILS_NOT_SAVED);
	}

	@Override
	public List<CategoriesDTO> getCategories() {
		log.info(CategoriesConstant.ENTERED_INTO_GET_CATEGORIES_SERVICE);
		List<CategoriesDTO> categoriesList = new ArrayList<>();
		List<Categories> findAll = categoriesRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(categories -> {
				CategoriesDTO categoriesDTO = new CategoriesDTO();
				BeanUtils.copyProperties(categories, categoriesDTO);
				categoriesDTO.setDepartmentId(categories.getDepartments().getDepartmentId());
				categoriesList.add(categoriesDTO);
			});
			return categoriesList;
		}
		log.info(CategoriesConstant.EXCEPTION_OCCURED_IN_GET_CATEGORIES_SERVICE);
		throw new CategoriesNotFoundException(CategoriesConstant.CATEGORIES_NOT_FOUND);
	}
 
	@Override
	public CategoriesDTO updateCategories(CategoriesDTO categoriesDTO) {
		log.info(CategoriesConstant.ENTERED_INTO_UPDATE_CATEGORIES_METHOD_IN_SERVICE);
		Optional<Categories> categoriesId = categoriesRepository.findByCategoryId(categoriesDTO.getCategoryId());
		if (categoriesId.isPresent()) {
			BeanUtils.copyProperties(categoriesDTO, categoriesId.get());
			categoriesRepository.save(categoriesId.get());
			BeanUtils.copyProperties(categoriesId.get(), categoriesDTO);
			return categoriesDTO;
		}
		log.info(CategoriesConstant.EXCEPTION_OCCURED_IN_UPDATE_CATEGORIES_SERVICE);
		throw new IdNotFoundException(CategoriesConstant.ID_NOT_PRESENT);
	}

	@Override
	public CategoriesDTO deleteCategories(Integer categoryId) {
		log.info(CategoriesConstant.ENTERED_INTO_DELETE_CATEGORIES_METHOD_IN_SERVICE);
		Optional<Categories> categoriesId = categoriesRepository.findByCategoryId(categoryId);
		if (categoriesId.isPresent()) {
			categoriesRepository.deleteById(categoriesId.get().getCategoryId());
			return new CategoriesDTO();
		}
		log.info(CategoriesConstant.EXCEPITON_OCCURED_IN_DELETE_CATEGORIES_SERVICE);
		throw new IdNotFoundException(CategoriesConstant.ID_NOT_PRESENT);
	}
}
