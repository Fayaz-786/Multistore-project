package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.ProductVariationDTO;

public interface ProductVariationService {
	public ProductVariationDTO register(ProductVariationDTO productVariationDTO);
	public ProductVariationDTO deleteProductVariation(Integer productVariationId);
	public List<ProductVariationDTO> getProductVariation();
	public ProductVariationDTO updateProductVariation(ProductVariationDTO productVariationDTO);

}
