package com.technoelevate.productcategorymanagementsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Products")
public class Products {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private Integer productId;

	@Column(name = "product_title")
	private String productTitle;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "Departments-Products")
	private Departments departments;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "Categories-Products")
	private Categories categories;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "VariationTypes-Products")
	private VariationTypes variationTypes;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "OptionTypes-Products")
	private OptionTypes optionTypes;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "products")
	@JsonManagedReference(value = "Product-ProductVariations")
	private List<ProductVariations> productVariations;

}
