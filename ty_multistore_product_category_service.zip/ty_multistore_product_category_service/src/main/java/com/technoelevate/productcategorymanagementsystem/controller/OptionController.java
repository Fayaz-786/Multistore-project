package com.technoelevate.productcategorymanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.OptionConstant;
import com.technoelevate.productcategorymanagementsystem.dto.OptionDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.OptionService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class OptionController {

	@Autowired
	private OptionService optionService;

	@PostMapping("/registerOption")
	public ResponseEntity<ResponseDTO> register(@RequestBody OptionDTO optionDTO) {
		log.info(OptionConstant.ENTERED_INTO_REGISTER_OPTION_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, OptionConstant.SUCCESS, optionService.register(optionDTO)));
	}

	@GetMapping("/getOption")
	public ResponseEntity<ResponseDTO> getOption() {
		log.info(OptionConstant.ENTERED_INTO_GET_OPTION_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, OptionConstant.GET_OPTION, optionService.getOption()));

	}

	@PutMapping("/UpdateOption")
	public ResponseEntity<ResponseDTO> updateOption(@RequestBody OptionDTO optionDTO) {
		log.info(OptionConstant.ENTERED_INTO_UPDATE_OPTION_CONTROLLER);
		return ResponseEntity
				.ok(new ResponseDTO(false, OptionConstant.UPDATE_SUCCESSFULLY, optionService.updateOption(optionDTO)));

	}

	@DeleteMapping("/deleteOption/{id}")
	public ResponseEntity<ResponseDTO> deleteOption(@PathVariable Integer id) {
		log.info(OptionConstant.ENTERED_INTO_DELETE_OPTION_CONTROLLER);
		return ResponseEntity
				.ok(new ResponseDTO(false, OptionConstant.DELETE_SUCCESSFULLY, optionService.deleteOption(id)));

	}

}
