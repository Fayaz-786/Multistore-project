package com.technoelevate.productcategorymanagementsystem.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.DepartmentsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.DepartmentsDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.DepartmentsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class DepartmentsController {

	@Autowired
	private DepartmentsService departmentsService;

	@PostMapping("/saveDepartments")
	public ResponseEntity<ResponseDTO> saveDepartments(@Valid @RequestBody DepartmentsDTO departmentsDto) {
		log.info(DepartmentsConstant.ENTERED_INTO_SAVE_DEPARTMENTS_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, DepartmentsConstant.DEPARTMENTS_DETAILS_SAVED_SUCCESSFULLY,
				departmentsService.saveDepartments(departmentsDto)));
	}

	@GetMapping("/getDepartments")
	public ResponseEntity<ResponseDTO> getDepartments() {
		log.info(DepartmentsConstant.ENTERED_INTO_GET_DEPARTMENTS_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, DepartmentsConstant.DETAILS_OF_DEPARTMENTS,
				departmentsService.getDepartments()));
	}

	@PutMapping("/updateDepartments")
	public ResponseEntity<ResponseDTO> updateDepartments(@Valid @RequestBody DepartmentsDTO departmentsDto) {
		log.info(DepartmentsConstant.ENTERED_INTO_UPDATE_DEPARTMENTS_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, DepartmentsConstant.DEPARTMENTS_UPDATED_SUCCESSFULLY,
				departmentsService.updateDepartments(departmentsDto)));
	}

	@DeleteMapping("/deleteDepartments/{departmentId}")
	public ResponseEntity<ResponseDTO> deleteDepartments(@PathVariable Integer departmentId) {
		log.info(DepartmentsConstant.ENTERED_INTO_DELETE_DEPARTMENTS_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, DepartmentsConstant.DEPARTMENTS_DELETED_SUCCESSFULLY,
				departmentsService.deleteDepartments(departmentId)));
	}

}
