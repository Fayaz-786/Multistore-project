package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.OptionDTO;

public interface OptionService {
	public OptionDTO register(OptionDTO optionDTO);
	public List<OptionDTO> getOption();
	public OptionDTO updateOption(OptionDTO optionDTO);
	public OptionDTO deleteOption(Integer optionId);
}
