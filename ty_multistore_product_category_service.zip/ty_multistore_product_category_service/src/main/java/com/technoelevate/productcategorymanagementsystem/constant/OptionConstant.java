package com.technoelevate.productcategorymanagementsystem.constant;

public class OptionConstant {

	/* ----------------------GET------------------------------------------ */

	public static final String GET_OPTION = "get all option";
	public static final String EXCEPTION_OCCURED_IN_GET_OPTION = "Something went wrong";
	/*-------------------------------- register---------------------------------------------------------- */
	public static final String SUCCESS = "Registration Successful";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong";

	public static final String ENTERED_INTO_REGISTER_CONTROLLER = "Entered into Register controller";
	public static final String ENTERED_INTO_REGISTER_OPTION = "Entered inside register option service";
	public static final String EXCEPTION_OCCURED_IN_REGISTER_OPTION_SERVICE = "Entered inside register";

	/*-------------------------------- UPDATE--------------------------------------------- */
	public static final String UPDATE_SUCCESSFULLY = "Updated Sucessfully";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_OPTION = "Something went wrong";
	public static final String ID_NOT_PRESENT = "Something went wrong";
	/*------------------------------------------- delete ------------------------------------*/
	public static final String DELETE_SUCCESSFULLY = "Delete Sucessfully";
	public static final String ENTERED_INTO_DELETE_METHOD_SERVICE = "Delete Sucessfully";

	/*-------------------------------------------Controller ------------------------------------*/
	public static final String ENTERED_INTO_REGISTER_OPTION_CONTROLLER = "Entered into Register option method of controller";
	public static final String ENTERED_INTO_GET_OPTION_CONTROLLER = "Entered into get option method of controller";
	public static final String ENTERED_INTO_UPDATE_OPTION_CONTROLLER = "Entered into update option method of controller";
	public static final String ENTERED_INTO_DELETE_OPTION_CONTROLLER = "Entered into delete option method of controller";
	/*-------------------------------------------service ------------------------------------*/
	public static final String ENTERED_INTO_REGISTER_OPTION_SERVICE = "Entered into Register option method of service";
	public static final String ENTERED_INTO_GET_OPTION_SERVICE = "Entered into get option method of service";
	public static final String EXCEPTION_OCCURED_IN_GET_OPTION_SERVICE = "Exception occured in get departments service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_OPTION_SERVICE = "Exception occured in update departments service";
	public static final String EXCEPTION_OCCURED_IN_DELETE_OPTION_SERVICE = "Exception occured in delete departments service";

}
