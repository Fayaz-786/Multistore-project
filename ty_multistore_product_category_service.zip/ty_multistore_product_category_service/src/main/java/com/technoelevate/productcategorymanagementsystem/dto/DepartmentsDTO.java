package com.technoelevate.productcategorymanagementsystem.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DepartmentsDTO {

	private Integer departmentId;

	@NotBlank(message = "department title not be empty")
	private String departmentTitle;

}
