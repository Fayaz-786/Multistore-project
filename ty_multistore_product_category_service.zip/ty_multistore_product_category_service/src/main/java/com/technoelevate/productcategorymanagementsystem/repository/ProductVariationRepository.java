package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.Options;
import com.technoelevate.productcategorymanagementsystem.entity.ProductVariations;

public interface ProductVariationRepository extends JpaRepository<ProductVariations, Integer>{
	Optional<Options> productVariationId(Integer productVariationId);
}
