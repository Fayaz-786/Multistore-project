package com.technoelevate.productcategorymanagementsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetailsDTO {

	private String productTitle;
	private String departmentTitle;
	private String categoryTitle;
	private String variationTypeTitle;
	private String optionTypeTitle;

}
