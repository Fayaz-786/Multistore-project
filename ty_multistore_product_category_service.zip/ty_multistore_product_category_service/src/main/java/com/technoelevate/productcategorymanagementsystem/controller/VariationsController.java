package com.technoelevate.productcategorymanagementsystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.VariationsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.dto.VariationsDTO;
import com.technoelevate.productcategorymanagementsystem.service.VariationsService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1/variation")
public class VariationsController {

	@Autowired
	private VariationsService variationsService;

	@PostMapping("/create")
	public ResponseEntity<ResponseDTO> saveVariations(@RequestBody VariationsDTO variationsDto) {
		log.info(VariationsConstant.ENTERED_INTO_SAVE_VARIARTIONS_CONTROLLER);

		return ResponseEntity.ok(new ResponseDTO(false, VariationsConstant.VARIATIONS_DETAILS_SAVED_SUCCESSFULLY,
				variationsService.saveVariations(variationsDto)));
	}

	@GetMapping("/details")
	public ResponseEntity<ResponseDTO> getVariations() {
		log.info(VariationsConstant.ENTERED_INTO_GET_VARIARTIONS_CONTROLLER);
		return ResponseEntity.ok(
				new ResponseDTO(false, VariationsConstant.GET_VARIATIONS_DETAILS, variationsService.getVariations()));
	}

	@DeleteMapping("/delete/{variationId}")
	public ResponseEntity<ResponseDTO> delete(@PathVariable Integer variationId) {
		log.info(VariationsConstant.ENTERED_INTO_DELETE_VARIATION_CONTROLLER);
		return new ResponseEntity<>(
				new ResponseDTO(false, VariationsConstant.DELETED, variationsService.deleteVariations(variationId)),
				HttpStatus.OK);

	}

	@PostMapping("/update/{variationId}")
	public ResponseEntity<ResponseDTO> update(@RequestBody VariationsDTO variationdto,
			@PathVariable Integer variationId) {
		log.info(VariationsConstant.ENTERED_INTO_UPDATE_VARIARTIONS_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, VariationsConstant.UPDATED,
				variationsService.update(variationdto, variationId)));

	}
}
