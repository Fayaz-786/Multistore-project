package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.DepartmentsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.DepartmentsDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Departments;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentsNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.DepartmentsNotSavedException;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.repository.DepartmentsRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DepartmentsServiceImpl implements DepartmentsService {

	@Autowired
	private DepartmentsRepository departmentsRepository;
 
	@Override
	public DepartmentsDTO saveDepartments(DepartmentsDTO departmentsDto) {
		log.info(DepartmentsConstant.ENTERED_INTO_SAVE_DEPARTMENT_SERVICE);
		Optional<Departments> findByDepartmentId = departmentsRepository
				.findByDepartmentId(departmentsDto.getDepartmentId());
		if (findByDepartmentId.isEmpty()) {
			Departments department = new Departments();
			BeanUtils.copyProperties(departmentsDto, department);
			Departments save = departmentsRepository.save(department);
			BeanUtils.copyProperties(save, departmentsDto);
			return departmentsDto;
		}
		log.info(DepartmentsConstant.EXCEPTION_OCCURED_IN_SAVE_DEPARTMENTS_SERVICE);
		throw new DepartmentsNotSavedException(DepartmentsConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public List<DepartmentsDTO> getDepartments() {
		log.info(DepartmentsConstant.ENTERED_INTO_GET_DEPARTMENTS_SERVICE);
		List<DepartmentsDTO> departmentsList = new ArrayList<>();
		List<Departments> findAll = departmentsRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(i -> {
				DepartmentsDTO departmentsDto = new DepartmentsDTO();
				BeanUtils.copyProperties(i, departmentsDto);
				departmentsList.add(departmentsDto);
			});
			return departmentsList;
		}
		log.info(DepartmentsConstant.EXCEPTION_OCCURED_IN_GET_DEPARTMENTS_SERVICE);
		throw new DepartmentsNotFoundException(DepartmentsConstant.DEPARTMENTS_NOT_FOUND);
	}
 
	@Override
	public DepartmentsDTO updateDepartments(DepartmentsDTO departmentsDto) {
		log.info(DepartmentsConstant.ENTERED_INTO_UPDATE_DEPARTMENTS_METHOD_IN_SERVICE);
		Optional<Departments> departmentsId = departmentsRepository.findById(departmentsDto.getDepartmentId());
		if (departmentsId.isPresent()) {
			BeanUtils.copyProperties(departmentsDto, departmentsId.get());
			departmentsRepository.save(departmentsId.get());
			BeanUtils.copyProperties(departmentsId.get(), departmentsDto);
			return departmentsDto;
		}
		log.info(DepartmentsConstant.EXCEPTION_OCCURED_IN_UPDATE_DEPARTMENT_SERVICE);
		throw new IdNotFoundException(DepartmentsConstant.ID_NOT_PRESENT);
	}

	@Override
	public DepartmentsDTO deleteDepartments(Integer departmentId) {

		log.info(DepartmentsConstant.ENTERED_INTO_DELETE_DEPARTMENTS_METHOD_IN_SERVICE);
		Optional<Departments> departmentsId = departmentsRepository.findById(departmentId);
		if (departmentsId.isPresent()) {
			departmentsRepository.deleteById(departmentId);
			return new DepartmentsDTO();
		}
		log.info(DepartmentsConstant.EXCEPITON_OCCURED_IN_DELETE_DEPARTMENTS_SERVICE);
		throw new IdNotFoundException(DepartmentsConstant.ID_NOT_PRESENT);

	}

}
