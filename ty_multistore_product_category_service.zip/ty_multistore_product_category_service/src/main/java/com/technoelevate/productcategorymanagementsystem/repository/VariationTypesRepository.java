package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.technoelevate.productcategorymanagementsystem.entity.VariationTypes;

@Repository
public interface VariationTypesRepository extends JpaRepository<VariationTypes, Integer> {

	Optional<VariationTypes> findByVariationTypeId(Integer variationTypeId);

}
