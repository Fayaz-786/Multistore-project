package com.technoelevate.productcategorymanagementsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "Options")
public class Options {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "option_id")
	private Integer optionId;

	@Column(name = "option_title")
	private String optionTitle;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "OptionTypes-Options")
	private OptionTypes optionTypes;

	@ManyToMany(cascade = CascadeType.PERSIST, mappedBy = "options")
	private List<ProductVariations> productVariations;

}
