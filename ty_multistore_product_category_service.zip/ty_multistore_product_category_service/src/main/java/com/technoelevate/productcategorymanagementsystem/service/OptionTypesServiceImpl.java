package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.CategoriesConstant;
import com.technoelevate.productcategorymanagementsystem.constant.OptionTypesConstant;
import com.technoelevate.productcategorymanagementsystem.dto.OptionTypesDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Categories;
import com.technoelevate.productcategorymanagementsystem.entity.OptionTypes;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.OptionTypesNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.OptionTypesNotSavedException;
import com.technoelevate.productcategorymanagementsystem.repository.CategoriesRepository;
import com.technoelevate.productcategorymanagementsystem.repository.OptionTypesRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OptionTypesServiceImpl implements OptionTypesService {

	@Autowired
	private OptionTypesRepository optionTypesRepository;

	@Autowired
	private CategoriesRepository categoriesRepository;

	@Override
	public OptionTypesDTO saveOptionTypes(OptionTypesDTO optionTypesDTO) {
		log.info(OptionTypesConstant.ENTERED_INTO_SAVE_OPTIONTYPES_SERVICE);
		Optional<OptionTypes> findByOptionTypeId = optionTypesRepository
				.findByOptionTypeId(optionTypesDTO.getOptionTypeId());
		Optional<Categories> findBycategoryId = categoriesRepository
				.findByCategoryId(optionTypesDTO.getCategoryId());
		if (findByOptionTypeId.isEmpty() && findBycategoryId.isPresent()) {
			Categories categories = findBycategoryId.get();
			OptionTypes optionTypes = new OptionTypes();
			BeanUtils.copyProperties(optionTypesDTO, optionTypes);
			optionTypes.setCategories(categories);
			OptionTypes save = optionTypesRepository.save(optionTypes);
			BeanUtils.copyProperties(save, optionTypesDTO);
			return optionTypesDTO;
		}
		log.info(OptionTypesConstant.EXCEPTION_OCCURED_IN_SAVE_OPTIONTYPES_SERVICE);
		throw new OptionTypesNotSavedException(OptionTypesConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public List<OptionTypesDTO> getOptionTypes() {
		log.info(OptionTypesConstant.ENTERED_INTO_GET_OPTIONTYPES_SERVICE);
		List<OptionTypesDTO> optionTypesList = new ArrayList<>();
		List<OptionTypes> findAll = optionTypesRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(i -> {
				OptionTypesDTO optionTypesDTO = new OptionTypesDTO();
				BeanUtils.copyProperties(i, optionTypesDTO);
				optionTypesList.add(optionTypesDTO);
			});
			return optionTypesList;
		}
		log.info(OptionTypesConstant.EXCEPTION_OCCURED_IN_GET_OPTIONTYPES_SERVICE);
		throw new OptionTypesNotFoundException(OptionTypesConstant.OPTIONTYPES_NOT_FOUND);
	}

	@Override
	public OptionTypesDTO updateOptionTypes(OptionTypesDTO optionTypesDTO) {
		log.info(OptionTypesConstant.ENTERED_INTO_UPDATE_OPTIONTYPES_METHOD_IN_SERVICE);
		Optional<OptionTypes> optionTypesId = optionTypesRepository.findById(optionTypesDTO.getOptionTypeId());
		if (optionTypesId.isPresent()) {
			BeanUtils.copyProperties(optionTypesDTO, optionTypesId.get());
			optionTypesRepository.save(optionTypesId.get());
			BeanUtils.copyProperties(optionTypesId.get(), optionTypesDTO);
			return optionTypesDTO;
		}
		log.info(OptionTypesConstant.EXCEPTION_OCCURED_IN_UPDATE_OPTIONTYPES_SERVICE);
		throw new IdNotFoundException(CategoriesConstant.ID_NOT_PRESENT);
	}

	@Override
	public OptionTypesDTO deleteOptionTypes(Integer optionTypeId) {
		log.info(OptionTypesConstant.ENTERED_INTO_DELETE_OPTIONTYPES_METHOD_IN_SERVICE);
		Optional<OptionTypes> optionTypesId = optionTypesRepository.findById(optionTypeId);
		if (optionTypesId.isPresent()) {
			optionTypesRepository.deleteById(optionTypeId);
			return new OptionTypesDTO();
		}
		log.info(OptionTypesConstant.EXCEPTION_OCCURED_IN_DELETE_OPTIONTYPES_SERVICE);
		throw new IdNotFoundException(OptionTypesConstant.ID_NOT_PRESENT);
	}
}
