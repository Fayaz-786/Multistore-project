package com.technoelevate.productcategorymanagementsystem.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CategoriesDTO {

	private Integer categoryId;

	@NotBlank(message = "category title not be empty")
	private String categoryTitle;

	private Integer departmentId;
}
