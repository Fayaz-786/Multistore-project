package com.technoelevate.productcategorymanagementsystem.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.technoelevate.productcategorymanagementsystem.constant.CategoriesConstant;
import com.technoelevate.productcategorymanagementsystem.dto.CategoriesDTO;
import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;
import com.technoelevate.productcategorymanagementsystem.service.CategoriesService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class CategoriesController {

	@Autowired
	private CategoriesService categoriesService;

	@PostMapping("/saveCategories")
	public ResponseEntity<ResponseDTO> saveCategories(@Valid @RequestBody CategoriesDTO categoriesDTO) {
		log.info(CategoriesConstant.ENTERED_INTO_SAVE_CATEGORIES_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok(new ResponseDTO(false, CategoriesConstant.CATEGORIES_DETAILS_SAVED_SUCCESSFULLY,
				categoriesService.saveCategories(categoriesDTO)));
	}

	@GetMapping("/getCategories")
	public ResponseEntity<ResponseDTO> getCategories() {
		log.info(CategoriesConstant.ENTERED_INTO_GET_CATEGORIES_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(
				new ResponseDTO(false, CategoriesConstant.DETAILS_OF_CATEGORIES, categoriesService.getCategories()));
	}

	@PutMapping("/updateCategories")
	public ResponseEntity<ResponseDTO> updatecategories(@Valid @RequestBody CategoriesDTO categoriesDTO) {
		log.info(CategoriesConstant.ENTERED_INTO_UPDATE_CATEGORIES_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, CategoriesConstant.CATEGORIES_UPDATED_SUCCESSFULLY,
				categoriesService.updateCategories(categoriesDTO)));
	}

	@DeleteMapping("/deleteCategories/{categoryId}")
	public ResponseEntity<ResponseDTO> deleteCategories(@PathVariable Integer categoryId) {
		log.info(CategoriesConstant.ENTERED_INTO_DELETE_CATEGORIES_METHOD_OF_CONTROLLER);
		return ResponseEntity.ok().body(new ResponseDTO(false, CategoriesConstant.CATEGORIES_DELETED_SUCCESSFULLY,
				categoriesService.deleteCategories(categoryId)));
	}

}
