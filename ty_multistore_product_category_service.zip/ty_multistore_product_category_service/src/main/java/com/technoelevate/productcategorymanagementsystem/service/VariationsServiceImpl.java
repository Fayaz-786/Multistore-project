package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.VariationsConstant;
import com.technoelevate.productcategorymanagementsystem.dto.VariationsDTO;
import com.technoelevate.productcategorymanagementsystem.entity.Variations;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.VariationDetailsNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.VariationsNotSavedException;
import com.technoelevate.productcategorymanagementsystem.repository.VariationsRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class VariationsServiceImpl implements VariationsService {

	@Autowired
	private VariationsRepository variationsRepository;

	@Override
	public VariationsDTO saveVariations(VariationsDTO variationsDTO) {
		log.info(VariationsConstant.ENTERED_INTO_REGISTER_VARIATIONS);
		Optional<Variations> findByVariationId = variationsRepository
				.findByVariationId(variationsDTO.getVariationId());
		if (findByVariationId.isEmpty()) {
			Variations variation = new Variations();
			BeanUtils.copyProperties(variationsDTO, variation);
			Variations save = variationsRepository.save(variation);
			BeanUtils.copyProperties(save, variationsDTO);
			return variationsDTO;
		}
		throw new VariationsNotSavedException(VariationsConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public List<VariationsDTO> getVariations() {

		// List<ProductsDTO> list = productsRepository.findAll();
		log.info(VariationsConstant.ENTERED_INTO_GET_VARIATIONS);
		List<Variations> findAll = variationsRepository.findAll(); 
		List<VariationsDTO> list = new ArrayList<>();
		for (Variations variation : findAll) {
			VariationsDTO variationsdto = new VariationsDTO(variation.getVariationId(), variation.getVariationTitle());
			list.add(variationsdto);
			return list;
		}
		throw new VariationDetailsNotFoundException(VariationsConstant.SOMETHING_WENT_WRONG);
	}

	@Override
	public VariationsDTO deleteVariations(Integer variationId) {

		if (variationsRepository.findByVariationId(variationId) != null) {
			Optional<Variations> findByVariationId = variationsRepository.findByVariationId(variationId);
			if(findByVariationId.isPresent())
			variationsRepository.delete(findByVariationId.get());
			return new VariationsDTO();
		}
		log.info(VariationsConstant.EXCEPTION_OCCURED_IN_DELETE_VARIATIONS);
		throw new IdNotFoundException(VariationsConstant.VARIATION_ID_NOT_FOUND);
	}

	@Override
	public VariationsDTO update(VariationsDTO variationsdto, Integer variationId) {
		Optional<Variations> findByVariationId = variationsRepository.findByVariationId(variationsdto.getVariationId());
		if (findByVariationId.isPresent()) {
			Variations variation = findByVariationId.get();
			BeanUtils.copyProperties(variationsdto, variation);
			variationsRepository.save(variation);
			BeanUtils.copyProperties(variation, variationsdto);
			return variationsdto;
		}
		log.info(VariationsConstant.EXCEPTION_OCCURED_IN_UPDATE_VARAIATIONS);
		throw new IdNotFoundException(VariationsConstant.VARIATION_ID_NOT_FOUND);
	}

}
