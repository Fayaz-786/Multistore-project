package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.Products;

public interface ProductsRepository extends JpaRepository<Products, Integer> {

	Optional<Products> findByProductId(Integer productId);


}
