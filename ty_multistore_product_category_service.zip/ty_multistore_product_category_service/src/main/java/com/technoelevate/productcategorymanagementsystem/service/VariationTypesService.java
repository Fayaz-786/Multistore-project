package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.VariationTypesDTO;

public interface VariationTypesService {
	public VariationTypesDTO register(VariationTypesDTO variationTypesDTO);
	public VariationTypesDTO deleteVariationTypes(Integer variationTypeId);
	public List<VariationTypesDTO> getVariationTypes();
	public VariationTypesDTO updateVariationTypes(VariationTypesDTO variationTypesDTO);


}
