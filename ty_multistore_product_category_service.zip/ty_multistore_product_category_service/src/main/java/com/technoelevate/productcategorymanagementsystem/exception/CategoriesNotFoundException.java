package com.technoelevate.productcategorymanagementsystem.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@SuppressWarnings("serial")
@Getter
@AllArgsConstructor
public class CategoriesNotFoundException extends RuntimeException {

	private final String message;
}
