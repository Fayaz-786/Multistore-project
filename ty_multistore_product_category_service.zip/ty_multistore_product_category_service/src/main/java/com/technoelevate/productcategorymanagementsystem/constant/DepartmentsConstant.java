package com.technoelevate.productcategorymanagementsystem.constant;

public class DepartmentsConstant {

	/** Departments entity controller constants messages */

	public static final String DEPARTMENTS_DETAILS_SAVED_SUCCESSFULLY = "departments details saved successfully";
	public static final String DETAILS_OF_DEPARTMENTS = "Details of departments";
	public static final String DEPARTMENTS_UPDATED_SUCCESSFULLY = "departments updated successfully";
	public static final String DEPARTMENTS_DELETED_SUCCESSFULLY = "departments deleted successfully";

	public static final String ENTERED_INTO_SAVE_DEPARTMENTS_METHOD_OF_CONTROLLER = "Entered into save departments method of controller";
	public static final String ENTERED_INTO_GET_DEPARTMENTS_METHOD_OF_CONTROLLER = "Entered into get departments method of controller";
	public static final String ENTERED_INTO_UPDATE_DEPARTMENTS_OF_CONTROLLER = "Entered into update departments of controller";
	public static final String ENTERED_INTO_DELETE_DEPARTMENTS_METHOD_OF_CONTROLLER = "Entered into delete departments method of controller";

	/** Exception constant messages */
	public static final String SOMETHING_WENT_WRONG = "something went wrong";
	public static final String DEPARTMENTS_NOT_FOUND = "Departments not found";
	public static final String ID_NOT_PRESENT = "Id not present";

	/** Departments entity Service messages */
	public static final String ENTERED_INTO_SAVE_DEPARTMENT_SERVICE = "Entered into save department service";
	public static final String ENTERED_INTO_GET_DEPARTMENTS_SERVICE = "Entered into get departments service";
	public static final String ENTERED_INTO_UPDATE_DEPARTMENTS_METHOD_IN_SERVICE = "entered into update departments method in service";
	public static final String ENTERED_INTO_DELETE_DEPARTMENTS_METHOD_IN_SERVICE = "Entered into delete departments method in service";

	/** log exception message */
	public static final String EXCEPTION_OCCURED_IN_SAVE_DEPARTMENTS_SERVICE = "exception occured in save departments service";
	public static final String EXCEPTION_OCCURED_IN_GET_DEPARTMENTS_SERVICE = "exception occured in get departments service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_DEPARTMENT_SERVICE = "exception occured in update department service";
	public static final String EXCEPITON_OCCURED_IN_DELETE_DEPARTMENTS_SERVICE = "Excepiton occured in delete departments service";

}
