package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.Departments;

public interface DepartmentsRepository extends JpaRepository<Departments, Integer> {

	Optional<Departments> findByDepartmentId(Integer departmentId);

}
