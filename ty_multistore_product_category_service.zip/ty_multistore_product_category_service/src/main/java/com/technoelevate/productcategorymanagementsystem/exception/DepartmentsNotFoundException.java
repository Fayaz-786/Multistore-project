package com.technoelevate.productcategorymanagementsystem.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
@SuppressWarnings("serial")
public class DepartmentsNotFoundException extends RuntimeException {

	private final String message;
}
