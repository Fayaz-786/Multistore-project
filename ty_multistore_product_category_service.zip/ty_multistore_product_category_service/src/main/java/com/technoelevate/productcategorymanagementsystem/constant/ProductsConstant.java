package com.technoelevate.productcategorymanagementsystem.constant;

public class ProductsConstant {

	public static final String PRODUCTS_DETAILS_SAVED_SUCCESSFULLY = "Product details saved successfully";

	public static final String SOMETHING_WENT_WRONG = "something went wrong";

	public static final String GET_PRODUCT_DETAILS = "details of products";

	public static final String DELETED = "product deleted successfully";

	public static final String UPDATED = "product updated successfully";

	public static final String EXCEPTION_OCCURED_IN_UPDATE_PRODUCTS = "exception occured in update products";

	public static final String EXCEPTION_OCCURED_IN_SAVE_PRODUCTS = "exception occured in  save products";

	public static final String EXCEPTION_OCCURED_IN_GET_PRODUCTS = "exception occured in  get products";

	public static final String PRODUCT_ID_NOT_FOUND = "product id not found";

	public static final String EXCEPTION_OCCURED_IN_DELETE_PRODUCTS = "exception occured in delete products";

	public static final String ENTERED_INTO_SAVE_PRODUCTS = "entered into register products service";

	public static final String ENTERED_INTO_SAVE_PRODUCTS_CONTROLLER = "Entered into save products controller";

	public static final String ENTERED_INTO_GET_PRODUCTS_CONTROLLER = "entered into get products controller";

	public static final String ENTERED_INTO_DELETE_PRODUCTS_CONTROLLER = "entered into delete products controller";

	public static final String ENTERED_INTO_GET_PRODUCTS = "entered into getProduct service";

	public static final String ENTERED_INTO_UPDATE_PRODUCTS = "entered into update Product service";

	public static final String ENTERED_INTO_DELETE_PRODUCTS = "entered into delete Product service";

	public static final String PLEASE_ENTER_DEPARTMENT_DETAILS = "Please enter department details";
	public static final String PLEASE_ENTER_CATEGORY_DETAILS = "Please enter category details";
	public static final String PLEASE_ENTER_VALIDATION_TYPE_DETAILS = "Please enter validation type details";
	public static final String PLEASE_ENTER_OPTION_TYPE_DETAILS = "Please enter option type details";

}
