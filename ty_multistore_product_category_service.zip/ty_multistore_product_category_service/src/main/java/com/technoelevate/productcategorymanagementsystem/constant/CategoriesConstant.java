package com.technoelevate.productcategorymanagementsystem.constant;

public class CategoriesConstant {

	/** Categories entity controller constants messages */

	public static final String CATEGORIES_DETAILS_SAVED_SUCCESSFULLY = "categories details saved successfully";
	public static final String DETAILS_OF_CATEGORIES = "Details of categories";
	public static final String CATEGORIES_UPDATED_SUCCESSFULLY = "Categories updated successfully";
	public static final String CATEGORIES_DELETED_SUCCESSFULLY = "categories deleted successfully";

	public static final String ENTERED_INTO_SAVE_CATEGORIES_METHOD_OF_CONTROLLER = "Entered into save categories method of controller";
	public static final String ENTERED_INTO_GET_CATEGORIES_METHOD_OF_CONTROLLER = "Entered into get categories method of controller";
	public static final String ENTERED_INTO_UPDATE_CATEGORIES_OF_CONTROLLER = "Entered into update categories of controller";
	public static final String ENTERED_INTO_DELETE_CATEGORIES_METHOD_OF_CONTROLLER = "Entered into delete categories method of controller";

	/** Categories entity Service messages */
	public static final String ENTERED_INTO_SAVE_CATEGORIES_SERVICE = "Entered into save categories service";
	public static final String ENTERED_INTO_GET_CATEGORIES_SERVICE = "Entered into get categories service";
	public static final String ENTERED_INTO_UPDATE_CATEGORIES_METHOD_IN_SERVICE = "entered into update categories method in service";
	public static final String ENTERED_INTO_DELETE_CATEGORIES_METHOD_IN_SERVICE = "Entered into delete categories method in service";

	/** Exception constant messages */
	public static final String CATEGORIES_DETAILS_NOT_SAVED = "Categories details not saved";
	public static final String CATEGORIES_NOT_FOUND = "Categories not found";
	public static final String ID_NOT_PRESENT = "Id not present";

	/** log exception message */
	public static final String EXCEPTION_OCCURED_IN_SAVE_CATEGORIES_SERVICE = "exception occured in save categories service";
	public static final String EXCEPTION_OCCURED_IN_GET_CATEGORIES_SERVICE = "exception occured in get categories service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_CATEGORIES_SERVICE = "exception occured in update categories service";
	public static final String EXCEPITON_OCCURED_IN_DELETE_CATEGORIES_SERVICE = "Excepiton occured in delete categories service";

}
