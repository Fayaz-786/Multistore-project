package com.technoelevate.productcategorymanagementsystem.dto;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductsDTO {

	private Integer productId;

	@NotBlank(message = "product title not be empty")
	private String productTitle;

	private Integer departmentId;

	private Integer categoryId;

	private Integer variationTypeId;

	private Integer optionTypeId;

}
