package com.technoelevate.productcategorymanagementsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Option_Types")
public class OptionTypes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "option_type_id")
	private Integer optionTypeId;

	@Column(name = "option_type_title")
	private String optionTypeTitle;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "optionTypes")
	@JsonManagedReference(value = "OptionTypes-Products")
	private List<Products> products;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "optionTypes")
	@JsonManagedReference(value = "OptionTypes-Options")
	private List<Options> options;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "Categories-OptionTypes")
	private Categories categories;
}
