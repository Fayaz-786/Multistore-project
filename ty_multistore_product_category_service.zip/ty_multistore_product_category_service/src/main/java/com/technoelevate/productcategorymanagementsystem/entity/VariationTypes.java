package com.technoelevate.productcategorymanagementsystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Variation_Types")
public class VariationTypes {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "variation_type_id")
	private Integer variationTypeId;

	@Column(name = "variation_type_title")
	private String variationTypeTitle;

	@ManyToOne(cascade = CascadeType.PERSIST)
	@JsonBackReference(value = "Categories-VariationTypes")
	private Categories categories;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "variationTypes")
	@JsonManagedReference(value = "VariationTypes-Products")
	private List<Products> products;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "variationTypes")
	@JsonManagedReference(value = "VariationTypes-Variations")
	private List<Variations> variations;
}
