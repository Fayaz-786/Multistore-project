package com.technoelevate.productcategorymanagementsystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.technoelevate.productcategorymanagementsystem.entity.OptionTypes;

public interface OptionTypesRepository extends JpaRepository<OptionTypes, Integer> {

	Optional<OptionTypes> findByOptionTypeId(Integer optionTypeId);

}
