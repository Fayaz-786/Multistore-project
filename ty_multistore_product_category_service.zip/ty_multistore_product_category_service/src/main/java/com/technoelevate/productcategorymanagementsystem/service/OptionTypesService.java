package com.technoelevate.productcategorymanagementsystem.service;

import java.util.List;

import com.technoelevate.productcategorymanagementsystem.dto.OptionTypesDTO;

public interface OptionTypesService {

	public OptionTypesDTO saveOptionTypes(OptionTypesDTO optionTypesDTO);

	public List<OptionTypesDTO> getOptionTypes();

	public OptionTypesDTO updateOptionTypes(OptionTypesDTO optionTypesDTO);

	public OptionTypesDTO deleteOptionTypes(Integer optionTypeId);

}
