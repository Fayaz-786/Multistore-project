package com.technoelevate.productcategorymanagementsystem.exception;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.technoelevate.productcategorymanagementsystem.dto.ResponseDTO;

@RestControllerAdvice
public class GlobalExcepitonHandler {

	@ExceptionHandler(DepartmentsNotSavedException.class)
	public ResponseEntity<ResponseDTO> departmentsNotSaved(DepartmentsNotSavedException exception) {

		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(CategoriesNotSavedException.class)
	public ResponseEntity<ResponseDTO> categoriesNotSaved(CategoriesNotSavedException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(OptionTypesNotSavedException.class)
	public ResponseEntity<ResponseDTO> optionTypesNotsaved(OptionTypesNotSavedException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(DepartmentsNotFoundException.class)
	public ResponseEntity<ResponseDTO> departmentsNotFound(DepartmentsNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(CategoriesNotFoundException.class)
	public ResponseEntity<ResponseDTO> categoriesNotFound(CategoriesNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(OptionTypesNotFoundException.class)
	public ResponseEntity<ResponseDTO> optionTypesNotFound(OptionTypesNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(OptionNotFoundException.class)
	public ResponseEntity<ResponseDTO> optionNotFound(OptionNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(OptionNotRegisterException.class)
	public ResponseEntity<ResponseDTO> optionNotRegister(OptionNotRegisterException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(ProductVariationNotFoundException.class)
	public ResponseEntity<ResponseDTO> productVariationNotFound(ProductVariationNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(ProductVariationNotRegisterException.class)
	public ResponseEntity<ResponseDTO> productVariationNotRegister(ProductVariationNotRegisterException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(VariationTypesNotFoundException.class)
	public ResponseEntity<ResponseDTO> variationTypesNotFound(VariationTypesNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(VariationTypesNotRegisterException.class)
	public ResponseEntity<ResponseDTO> variationTypesNotRegister(VariationTypesNotRegisterException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(VariationsNotSavedException.class)
	public ResponseEntity<ResponseDTO> variationsNotSaved(VariationsNotSavedException variationsNotSavedException) {

		return ResponseEntity.badRequest().body(new ResponseDTO(true, variationsNotSavedException.getMessage(), null));
	}

	@ExceptionHandler(VariationDetailsNotFoundException.class)
	public ResponseEntity<ResponseDTO> variationDetailsNotFound(
			VariationDetailsNotFoundException variationDetailsNotFoundException) {

		return ResponseEntity.badRequest()
				.body(new ResponseDTO(true, variationDetailsNotFoundException.getMessage(), null));
	}

	@ExceptionHandler(ProductsNotSavedException.class)
	public ResponseEntity<ResponseDTO> productsNotSaved(ProductsNotSavedException productsNotSavedException) {

		return ResponseEntity.badRequest().body(new ResponseDTO(true, productsNotSavedException.getMessage(), null));
	}

	@ExceptionHandler(ProductDetailsNotFoundException.class)
	public ResponseEntity<ResponseDTO> productDetailsNotFound(ProductDetailsNotFoundException productdetailsNotFoundException) {

		return ResponseEntity.badRequest()
				.body(new ResponseDTO(true, productdetailsNotFoundException.getMessage(), null));
	}

	@ExceptionHandler(DepartmentIdNotFoundException.class)
	public ResponseEntity<ResponseDTO> departmentIdNotFound(DepartmentIdNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(CategoryIdNotFoundException.class)
	public ResponseEntity<ResponseDTO> categoryIdNotFoudn(CategoryIdNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(VariationTypeIdNotFoundException.class)
	public ResponseEntity<ResponseDTO> variationTypeIdNotFound(VariationTypeIdNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(OptionTypeIdNotFoundException.class)
	public ResponseEntity<ResponseDTO> optionTypeIdNotFound(OptionTypeIdNotFoundException exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

	@ExceptionHandler(ProductIsPresentExcepiton.class)
	public ResponseEntity<ResponseDTO> productIsPresent(ProductIsPresentExcepiton exception) {
		return ResponseEntity.badRequest().body(new ResponseDTO(true, exception.getMessage(), null));
	}

}
