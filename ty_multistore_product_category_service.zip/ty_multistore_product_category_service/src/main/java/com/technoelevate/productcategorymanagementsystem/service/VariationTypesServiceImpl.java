package com.technoelevate.productcategorymanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.technoelevate.productcategorymanagementsystem.constant.VariationTypesConstant;
import com.technoelevate.productcategorymanagementsystem.dto.VariationTypesDTO;
import com.technoelevate.productcategorymanagementsystem.entity.VariationTypes;
import com.technoelevate.productcategorymanagementsystem.exception.IdNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.VariationTypesNotFoundException;
import com.technoelevate.productcategorymanagementsystem.exception.VariationTypesNotRegisterException;
import com.technoelevate.productcategorymanagementsystem.repository.VariationTypesRepository;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class VariationTypesServiceImpl implements VariationTypesService {
	@Autowired
	private VariationTypesRepository variationTypesRepository;

	@Override
	public VariationTypesDTO register(VariationTypesDTO variationTypesDTO) {
			 log.info(VariationTypesConstant.ENTERED_INTO_REGISTER_VARIATION_TYPE_SERVICE);
		 Optional<VariationTypes> findByVariationId = variationTypesRepository.findByVariationTypeId(variationTypesDTO.getVariationTypeId());
			 if(findByVariationId.isEmpty()) {
			 
				 VariationTypes variationTypes = new VariationTypes();
		        

				
				BeanUtils.copyProperties(variationTypesDTO, variationTypes);
				  VariationTypes save = variationTypesRepository.save(variationTypes);
				BeanUtils.copyProperties(save, variationTypesDTO);
				return variationTypesDTO;
		}
			log.info(VariationTypesConstant.EXCEPTION_OCCURED_IN_REGISTER_VARIATION_TYPES_SERVICE);
			throw new VariationTypesNotRegisterException(VariationTypesConstant.SOMETHING_WENT_WRONG);
		
	}

	
	@Override
	public List<VariationTypesDTO> getVariationTypes() {
		log.info(VariationTypesConstant.ENTERED_INTO_GET_VARIATION_TYPE_SERVICE);
		List<VariationTypesDTO> variationTypesList = new ArrayList<>();
		 List<VariationTypes> findAll = variationTypesRepository.findAll();
		if (!findAll.isEmpty()) {
			findAll.forEach(i -> {
				VariationTypesDTO variationTypesDTO = new VariationTypesDTO();
				BeanUtils.copyProperties(i, variationTypesDTO);
				variationTypesList.add(variationTypesDTO);
			});

			return variationTypesList;
		}
        log.info(VariationTypesConstant.EXCEPTION_OCCURED_IN_GET_VARIATION_TYPES_SERVICE);
		throw new VariationTypesNotFoundException("VariationTypes not available, Please try again");
	}

	@Override
	public VariationTypesDTO updateVariationTypes(VariationTypesDTO variationTypesDTO) {
		log.info(VariationTypesConstant.ENTERED_INTO_UPADTE_VARIATION_TYPE_SERVICE);
		  Optional<VariationTypes> variationTypesId = variationTypesRepository.findById(variationTypesDTO.getVariationTypeId());
			if(variationTypesId.isPresent() ){
				BeanUtils.copyProperties(variationTypesDTO, variationTypesId.get());
				variationTypesRepository.save(variationTypesId.get());
				BeanUtils.copyProperties( variationTypesId.get(),variationTypesDTO);
				return variationTypesDTO;
			}
			 log.info(VariationTypesConstant.EXCEPTION_OCCURED_IN_UPDATE_VARIATION_TYPES_SERVICE);
			throw new IdNotFoundException(VariationTypesConstant.ID_NOT_PRESENT);
	}


	@Override
	public VariationTypesDTO deleteVariationTypes(Integer variationTypeId) {
		log.info(VariationTypesConstant.ENTERED_INTO_DELETE_VARIATION_TYPE_SERVICE);
		  Optional<VariationTypes> productVariatioId = variationTypesRepository.findById(variationTypeId);
		if(productVariatioId.isPresent()){
			variationTypesRepository.deleteById(variationTypeId);
		return new VariationTypesDTO();
		}
			log.info(VariationTypesConstant.EXCEPTION_OCCURED_IN_DELETE_VARIATION_TYPES_SERVICE);
			throw new IdNotFoundException(VariationTypesConstant.ID_NOT_PRESENT);
	}

}
