package com.technoelevate.productcategorymanagementsystem.constant;

public class VariationTypesConstant {
	/* ----------------------GET------------------------------------------ */

	public static final String EXCEPTION_OCCURED_IN_GET_VARIATION_TYPES = "Something went wrong";
	public static final String GET_VARIATION_TYPES = "get all variationtypes";

	/* ----------------------REGISTER------------------------------------------ */
	public static final String ENTERED_INTO_REGISTER = "Register the option";
	public static final String SUCCESS = "Registration Successful";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong";
	public static final String EXCEPTION_OCCURED_IN_REGISTER_VARIATION_TYPES = "Entered inside register";
	/* update ------------------------------------ */
	public static final String UPDATE_SUCCESSFULLY = "Updated Sucessfully";
	public static final String EXCEPTION_OCCURED_IN_UPDATE = "Something went wrong";
	public static final String ID_NOT_PRESENT = "Something went wrong";
	/* delete ------------------------------------ */
	public static final String DELETE_SUCCESSFULLY = "Delete Sucessfully";
	public static final String ENTERED_INTO_DELETE_METHOD_SERVICE = "Delete Sucessfully";
	public static final String EXCEPTION_OCCURED_IN_DELETE_VARIATION_TYPES = "Something went wrong";

	/*----------------------------------------- CONTROLLER--------------------------------- */
	public static final String ENTERED_INTO_REGISTER_VARIATION_TYPE_OF__CONTROLLER = "Entered into Register variationtypes method of controller";
	public static final String ENTERED_INTO_GET_VARIATION_TYPE_OF__CONTROLLER = "Entered into get variationtypes method of controller";
	public static final String ENTERED_INTO_UPDATE_VARIATION_TYPE_OF__CONTROLLER = "Entered into update variationtypes method of controller";
	public static final String ENTERED_INTO_DELETE_VARIATION_TYPE_OF__CONTROLLER = "Entered into delete variationtypes method of controller";
	/*----------------------------------------- ------service--------------------------------- */
	public static final String ENTERED_INTO_REGISTER_VARIATION_TYPE_SERVICE = "Entered into Register variationtypes method of service";
	public static final String EXCEPTION_OCCURED_IN_REGISTER_VARIATION_TYPES_SERVICE = "Exception into Register variationtypes method of service";
	public static final String ENTERED_INTO_GET_VARIATION_TYPE_SERVICE = "Entered into get variationtypes method of service";
	public static final String EXCEPTION_OCCURED_IN_GET_VARIATION_TYPES_SERVICE = "Exception into get variationtypes method of service";
	public static final String ENTERED_INTO_UPADTE_VARIATION_TYPE_SERVICE = "Entered into update variationtypes method of service";
	public static final String EXCEPTION_OCCURED_IN_UPDATE_VARIATION_TYPES_SERVICE = "Exception into update variationtypes method of service";
	public static final String ENTERED_INTO_DELETE_VARIATION_TYPE_SERVICE = "Entered into delete variationtypes method of service";
	public static final String EXCEPTION_OCCURED_IN_DELETE_VARIATION_TYPES_SERVICE = "Exception into delete variationtypes method of service";
}
